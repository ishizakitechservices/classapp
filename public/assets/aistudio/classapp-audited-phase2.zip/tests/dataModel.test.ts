import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  INITIAL_SUBJECTS,
  INITIAL_VAULT_FILES,
  INITIAL_NOTICES,
  SAMPLE_QUIZ_QUESTIONS,
  INITIAL_CONNECTED_SERVICES,
} from '../src/data/mockData';

test('Data Model: Subjects have valid syllabus and required fields', () => {
  assert.ok(INITIAL_SUBJECTS.length >= 4, 'At least 4 subjects defined');
  for (const s of INITIAL_SUBJECTS) {
    assert.ok(s.id, 'Subject has id');
    assert.ok(s.code, 'Subject has course code');
    assert.ok(s.name, 'Subject has name');
    assert.ok(s.syllabus.length > 0, 'Subject has syllabus topics');
    assert.ok(typeof s.progressPercent === 'number', 'Progress is number');
  }
});

test('Data Model: Vault files include readable document text and offline metadata', () => {
  assert.ok(INITIAL_VAULT_FILES.length >= 6, 'At least 6 vault files');
  for (const f of INITIAL_VAULT_FILES) {
    assert.ok(f.id, 'File has id');
    assert.ok(f.name, 'File has name');
    assert.ok(f.subjectCode, 'File has subject code');
    assert.ok(f.fileSize, 'File has size');
    assert.ok(f.keyConcepts.length > 0, 'File has key concepts');
    assert.ok(f.content && f.content.length > 50, 'File has readable content for offline document viewer');
  }
});

test('Data Model: Offline storage calculation computes correct size', () => {
  const offlineFiles = INITIAL_VAULT_FILES.filter((f) => f.isOffline);
  assert.ok(offlineFiles.length > 0, 'Has files designated for initial offline availability');

  const totalMB = offlineFiles.reduce((acc, f) => {
    const num = parseFloat(f.fileSize);
    if (f.fileSize.includes('KB')) return acc + num / 1024;
    return acc + (isNaN(num) ? 1 : num);
  }, 0);

  assert.ok(totalMB > 1.0 && totalMB < 50.0, 'Offline size falls within realistic mobile bounds');
});

test('Data Model: Quiz questions have valid answers and explanations', () => {
  assert.ok(SAMPLE_QUIZ_QUESTIONS.length >= 3, 'Has at least 3 quiz questions');
  for (const q of SAMPLE_QUIZ_QUESTIONS) {
    assert.ok(q.question, 'Question has prompt');
    assert.ok(q.options.length >= 3, 'Question has at least 3 choices');
    assert.ok(
      q.correctAnswerIndex >= 0 && q.correctAnswerIndex < q.options.length,
      'Valid correct answer index'
    );
    assert.ok(q.explanation.length > 20, 'Question provides detailed pedagogical explanation');
  }
});

test('Data Model: Connected services have official Google scopes and zero client secrets', () => {
  const classroom = INITIAL_CONNECTED_SERVICES.find((s) => s.id === 'google_classroom');
  const drive = INITIAL_CONNECTED_SERVICES.find((s) => s.id === 'google_drive');

  assert.ok(classroom, 'Google Classroom defined');
  assert.ok(drive, 'Google Drive defined');
  assert.ok(classroom.scopes.includes('https://www.googleapis.com/auth/classroom.courses.readonly'));
  assert.ok(drive.scopes.includes('https://www.googleapis.com/auth/drive.readonly'));
  // Verify no secrets embedded in configuration objects
  assert.equal((classroom as any).clientSecret, undefined);
  assert.equal((drive as any).clientSecret, undefined);
});
