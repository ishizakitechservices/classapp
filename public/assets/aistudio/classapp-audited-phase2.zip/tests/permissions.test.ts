import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  canManageClass,
  canPublishSchoolNotices,
  canManageUsers,
  UserRole,
} from '../src/types/index';

test('Permissions: student has no management permissions', () => {
  const role: UserRole = 'student';
  assert.equal(canManageClass(role, 'cs204', []), false);
  assert.equal(canManageClass(role, 'math201', []), false);
  assert.equal(canPublishSchoolNotices(role), false);
  assert.equal(canManageUsers(role), false);
});

test('Permissions: class_manager (prefect) only has permissions for assigned class', () => {
  const role: UserRole = 'class_manager';
  const assigned = ['cs204'];

  // Allowed on assigned class
  assert.equal(canManageClass(role, 'cs204', assigned), true);

  // Denied on any other class!
  assert.equal(canManageClass(role, 'math201', assigned), false);
  assert.equal(canManageClass(role, 'sci108', assigned), false);

  // Denied on school-wide notices and user management
  assert.equal(canPublishSchoolNotices(role), false);
  assert.equal(canManageUsers(role), false);
});

test('Permissions: class_admin has permissions for their assigned classes and notices', () => {
  const role: UserRole = 'class_admin';
  const assigned = ['cs204', 'cs210'];

  assert.equal(canManageClass(role, 'cs204', assigned), true);
  assert.equal(canManageClass(role, 'cs210', assigned), true);
  assert.equal(canManageClass(role, 'math201', assigned), false);

  assert.equal(canPublishSchoolNotices(role), true);
  assert.equal(canManageUsers(role), false);
});

test('Permissions: platform_owner has universal management authority', () => {
  const role: UserRole = 'platform_owner';

  assert.equal(canManageClass(role, 'cs204'), true);
  assert.equal(canManageClass(role, 'math201'), true);
  assert.equal(canManageClass(role, 'any_future_class'), true);

  assert.equal(canPublishSchoolNotices(role), true);
  assert.equal(canManageUsers(role), true);
});
