import { Subject, VaultFile, Notice, ChatMessage, UserProfile, QuizQuestion, Flashcard, ConnectedService } from '../types';

export const PROFILES: Record<string, UserProfile> = {
  student: {
    name: 'Alex Chen',
    idNumber: 'STU-2026-8841',
    email: 'alex.chen@student.classapp.edu',
    role: 'student',
    program: 'B.Sc. Computer Science & Data',
    semester: 'Semester 4 · Spring 2026',
    avatarInitials: 'AC',
    assignedClassIds: [],
  },
  class_manager: {
    name: 'Jordan Taylor',
    idNumber: 'PREFECT-2026-4019',
    email: 'jordan.taylor@student.classapp.edu',
    role: 'class_manager',
    program: 'B.Sc. Computer Science & Data',
    semester: 'Semester 4 · Class Prefect',
    avatarInitials: 'JT',
    assignedClassIds: ['cs204'], // Authorized to manage CS 204 only
  },
  class_admin: {
    name: 'Dr. Kwame Mensah',
    idNumber: 'FAC-1092',
    email: 'k.mensah@faculty.classapp.edu',
    role: 'class_admin',
    program: 'Department of Computing Sciences',
    semester: 'Course Director · Spring 2026',
    avatarInitials: 'KM',
    assignedClassIds: ['cs204', 'cs210'], // Authorized for CS 204 and CS 210
  },
  platform_owner: {
    name: 'Prof. Eleanor Sterling',
    idNumber: 'DIR-0001',
    email: 'e.sterling@admin.classapp.edu',
    role: 'platform_owner',
    program: 'Academic Affairs Board',
    semester: 'Dean of Studies · Administrator',
    avatarInitials: 'ES',
    assignedClassIds: ['cs204', 'math201', 'cs210', 'sci108'],
  },
};

export const INITIAL_CONNECTED_SERVICES: ConnectedService[] = [
  {
    id: 'google_classroom',
    name: 'Google Classroom',
    isConnected: false,
    scopes: ['https://www.googleapis.com/auth/classroom.courses.readonly', 'https://www.googleapis.com/auth/classroom.coursework.me.readonly'],
    autoSync: true,
  },
  {
    id: 'google_drive',
    name: 'Google Drive',
    isConnected: false,
    scopes: ['https://www.googleapis.com/auth/drive.readonly'],
    autoSync: false,
  },
];

export const INITIAL_SUBJECTS: Subject[] = [
  {
    id: 'cs204',
    code: 'CS 204',
    name: 'Data Structures & Algorithms',
    instructor: 'Dr. Kwame Mensah',
    instructorEmail: 'k.mensah@faculty.classapp.edu',
    room: 'Hall 3B, Turing Wing',
    schedule: 'Mon & Wed · 10:00 - 11:30 AM',
    progressPercent: 68,
    totalLectures: 24,
    attendedLectures: 22,
    description: 'Foundations of computational complexity, tree balancing, graph traversals, and dynamic programming.',
    nextSession: 'Today at 10:00 AM',
    syllabus: [
      { id: 's1', title: 'Asymptotic Analysis & Big-O Notation', week: 1, status: 'completed', date: 'Feb 3' },
      { id: 's2', title: 'Binary Search Trees & AVL Balancing', week: 3, status: 'completed', date: 'Feb 17' },
      { id: 's3', title: 'Graph Traversals: BFS, DFS & Dijkstra', week: 7, status: 'in_progress', date: 'Mar 17' },
      { id: 's4', title: 'Dynamic Programming: Memoization & Tabulation', week: 9, status: 'upcoming', date: 'Apr 07' },
      { id: 's5', title: 'NP-Completeness & Approximation Algorithms', week: 12, status: 'upcoming', date: 'Apr 28' },
    ],
    activities: [
      {
        id: 'act1',
        type: 'assignment',
        title: 'Problem Set 4: Shortest Paths in Directed Graphs',
        description: 'Implement Dijkstra and Bellman-Ford in C++ or Python with edge test suite.',
        dueDate: 'Friday, 11:59 PM',
        date: '2 days ago',
        author: 'Dr. Kwame Mensah',
        role: 'Course Director',
      },
      {
        id: 'act2',
        type: 'lecture',
        title: 'Lecture 14 Slides Posted: Topological Sorting',
        description: 'Review slide deck 14 prior to Wednesday laboratory session.',
        date: 'Yesterday',
        author: 'Dr. Kwame Mensah',
        role: 'Course Director',
      },
      {
        id: 'act3',
        type: 'announcement',
        title: 'Midterm Grade Review Office Hours',
        description: 'Office hours will run Thursday 2:00 - 4:00 PM in Room 412 or via ClassApp voice link.',
        date: '3 days ago',
        author: 'Jordan Taylor',
        role: 'Class Prefect',
      },
    ],
  },
  {
    id: 'math201',
    code: 'MATH 201',
    name: 'Multivariable Calculus & Linear Systems',
    instructor: 'Prof. Elena Rostova',
    instructorEmail: 'e.rostova@faculty.classapp.edu',
    room: 'Lecture Theatre B',
    schedule: 'Tue & Thu · 08:30 - 10:00 AM',
    progressPercent: 74,
    totalLectures: 26,
    attendedLectures: 25,
    description: 'Partial derivatives, multiple integrals, vector fields, Green’s and Stokes’ theorems with matrix eigenbases.',
    nextSession: 'Tomorrow at 08:30 AM',
    syllabus: [
      { id: 'm1', title: 'Vector Geometry and Planes in 3D', week: 1, status: 'completed', date: 'Feb 4' },
      { id: 'm2', title: 'Partial Derivatives & Gradient Vectors', week: 4, status: 'completed', date: 'Feb 25' },
      { id: 'm3', title: 'Double & Triple Integrals in Polar/Cylindrical', week: 7, status: 'in_progress', date: 'Mar 18' },
      { id: 'm4', title: 'Vector Analysis: Div, Curl, and Flux Integrals', week: 10, status: 'upcoming', date: 'Apr 09' },
    ],
    activities: [
      {
        id: 'm-act1',
        type: 'announcement',
        title: 'Formula Sheet Revision for Quiz 3',
        description: 'The updated standard formula sheet is uploaded in the Class Vault under worksheets.',
        date: '1 day ago',
        author: 'Prof. Elena Rostova',
        role: 'Instructor',
      },
      {
        id: 'm-act2',
        type: 'assignment',
        title: 'Homework 6: Surface Integrals & Gauss Divergence',
        description: 'Problems 12 through 28 from Section 16.4.',
        dueDate: 'Next Tuesday',
        date: '3 days ago',
        author: 'Prof. Elena Rostova',
        role: 'Instructor',
      },
    ],
  },
  {
    id: 'cs210',
    code: 'CS 210',
    name: 'Computer Systems & Architecture',
    instructor: 'Dr. Marcus Vance',
    instructorEmail: 'm.vance@faculty.classapp.edu',
    room: 'Lab 101, Silicon Wing',
    schedule: 'Tue & Thu · 01:00 - 02:30 PM',
    progressPercent: 55,
    totalLectures: 24,
    attendedLectures: 20,
    description: 'Hardware-software interface, machine-level representations of programs, memory hierarchy, and caching.',
    nextSession: 'Tomorrow at 01:00 PM',
    syllabus: [
      { id: 'cs210-1', title: 'Number Representations and Bitwise Logic', week: 1, status: 'completed', date: 'Feb 4' },
      { id: 'cs210-2', title: 'x86-64 Machine Instructions & Stack Frames', week: 4, status: 'completed', date: 'Feb 25' },
      { id: 'cs210-3', title: 'Cache Memory Organization & Miss Rates', week: 8, status: 'in_progress', date: 'Mar 24' },
      { id: 'cs210-4', title: 'Virtual Memory & Page Translation', week: 11, status: 'upcoming', date: 'Apr 14' },
    ],
    activities: [
      {
        id: 'c-act1',
        type: 'lecture',
        title: 'Lab 4 Manual: Cache Simulator Benchmark',
        description: 'Please review before your allocated lab slot.',
        date: 'Yesterday',
        author: 'Dr. Marcus Vance',
        role: 'Instructor',
      },
    ],
  },
  {
    id: 'sci108',
    code: 'CHEM 108',
    name: 'Principles of Physical Chemistry',
    instructor: 'Dr. Sarah Al-Mansoor',
    instructorEmail: 's.almansoor@faculty.classapp.edu',
    room: 'Science Complex 201',
    schedule: 'Fri · 09:00 - 12:00 PM',
    progressPercent: 82,
    totalLectures: 14,
    attendedLectures: 14,
    description: 'Chemical thermodynamics, equilibrium states, reaction kinetics, and spectroscopic methods.',
    nextSession: 'Friday at 09:00 AM',
    syllabus: [
      { id: 'ch1', title: 'First & Second Laws of Thermodynamics', week: 2, status: 'completed', date: 'Feb 13' },
      { id: 'ch2', title: 'Gibbs Free Energy & Chemical Equilibrium', week: 5, status: 'completed', date: 'Mar 06' },
      { id: 'ch3', title: 'Reaction Rates & Arrhenius Kinetics', week: 8, status: 'in_progress', date: 'Mar 27' },
      { id: 'ch4', title: 'Quantum Foundations & Molecular Orbitals', week: 12, status: 'upcoming', date: 'Apr 24' },
    ],
    activities: [
      {
        id: 'ch-act1',
        type: 'assignment',
        title: 'Lab Report: Enthalpy of Neutralization',
        description: 'Upload calculations sheet and error propagation summary.',
        dueDate: 'Friday 5:00 PM',
        date: '4 days ago',
        author: 'Dr. Sarah Al-Mansoor',
        role: 'Instructor',
      },
    ],
  },
];

export const INITIAL_VAULT_FILES: VaultFile[] = [
  {
    id: 'f1',
    name: 'CS204_Lecture14_GraphTraversals.pdf',
    folder: 'slides',
    subjectId: 'cs204',
    subjectCode: 'CS 204',
    fileSize: '3.4 MB',
    fileFormat: 'PDF',
    updatedAt: 'Mar 18, 2026',
    isOffline: true,
    downloadsCount: 142,
    description: 'Complete slide presentation detailing breadth-first search, depth-first search, edge classifications, and topological ordering with code samples.',
    keyConcepts: ['Breadth-First Search (BFS)', 'Depth-First Search (DFS)', 'Topological Sorting', 'Adjacency Lists vs Matrices'],
    content: `# CS 204: Graph Traversals & Topological Order
**Instructor**: Dr. Kwame Mensah | **Department of Computing Sciences**

---

### 1. Graph Representations
- **Adjacency Matrix**: A 2D array of size V × V. Lookup is O(1), but memory consumption is O(V²). Best suited for dense graphs where |E| ≈ |V|².
- **Adjacency List**: An array of lists of size V. Memory consumption is O(V + E). Faster for iterating through neighbors in sparse graphs.

---

### 2. Breadth-First Search (BFS)
- Uses a **FIFO Queue**.
- Explores vertices in radial order of distance from source $s$.
- Discovers shortest path in **unweighted graphs** in $O(V + E)$ time.
- Classifies edges into **tree edges** and **cross edges**.

---

### 3. Depth-First Search (DFS)
- Uses a **LIFO Stack** or call-stack recursion.
- Maintains entry time \`d[u]\` and finish time \`f[u]\`.
- Discovers back edges (indicating cycles), forward edges, and cross edges.
- Essential subroutine for finding strongly connected components (Kosaraju / Tarjan).

---

### 4. Topological Sorting
- Defined exclusively for **Directed Acyclic Graphs (DAGs)**.
- Linear ordering of vertices such that for every directed edge $(u, v)$, vertex $u$ comes before $v$.
- Can be constructed by sorting vertices by descending DFS finish times $f[u]$. Time complexity: $O(V + E)$.`,
    lastCachedAt: 'Mar 18, 2026',
    syncStatus: 'synced',
  },
  {
    id: 'f2',
    name: 'Dijkstra_Algorithm_Implementation_Guide.pdf',
    folder: 'notes',
    subjectId: 'cs204',
    subjectCode: 'CS 204',
    fileSize: '1.2 MB',
    fileFormat: 'PDF',
    updatedAt: 'Mar 16, 2026',
    isOffline: true,
    downloadsCount: 98,
    description: 'Step-by-step pseudo-code and priority queue invariants for single-source shortest path algorithms.',
    keyConcepts: ['Min-Heap Priority Queue', 'Edge Relaxation', 'Negative Weight Restrictions'],
    content: `# Dijkstra's Single-Source Shortest Path Guide
**Class Reference Notes**

---

### The Greedy Choice Invariant
At each step, extract vertex $u$ with minimum provisional distance $dist[u]$:
\`\`\`text
Initialize: dist[s] = 0, dist[v] = ∞ for v != s
PQ.insert((0, s))

While PQ not empty:
    (d, u) = PQ.extractMin()
    if d > dist[u]: continue   // Stale heap element
    
    for each edge (u, v, weight) in adj[u]:
        if dist[u] + weight < dist[v]:
            dist[v] = dist[u] + weight
            PQ.insert((dist[v], v))
\`\`\`

### Why Negative Weights Fail
Dijkstra permanently commits vertex distances once extracted from the heap. If a later edge has negative weight, it could lower the path length to an already finalized node, invalidating the proof by contradiction. Use **Bellman-Ford** ($O(V \\cdot E)$) for graphs with negative weights.`,
    lastCachedAt: 'Mar 16, 2026',
    syncStatus: 'synced',
  },
  {
    id: 'f3',
    name: 'MATH201_Midterm_Past_Paper_2025.pdf',
    folder: 'past_papers',
    subjectId: 'math201',
    subjectCode: 'MATH 201',
    fileSize: '2.1 MB',
    fileFormat: 'PDF',
    updatedAt: 'Mar 10, 2026',
    isOffline: false,
    downloadsCount: 230,
    description: 'Official midterm examination from Spring 2025 semester with worked solutions for partial derivatives and double integration.',
    keyConcepts: ['Lagrange Multipliers', 'Jacobian Transformations', 'Gradient Vectors'],
    content: `# MATH 201: Spring 2025 Midterm Examination
**Examiner**: Prof. Elena Rostova | **Duration**: 90 Minutes

---

### Question 1 (20 Marks)
Find the local extrema and saddle points of $f(x, y) = x^4 + y^4 - 4xy + 1$.
- $\\nabla f(x, y) = (4x^3 - 4y, 4y^3 - 4x) = (0, 0)$
- Critical points occur at $(0, 0), (1, 1), (-1, -1)$.
- Discriminant $D = f_{xx}f_{yy} - (f_{xy})^2 = (12x^2)(12y^2) - (-4)^2 = 144x^2y^2 - 16$.
- At $(0,0)$: $D = -16 < 0 \\implies$ Saddle point.
- At $(1,1)$ and $(-1,-1)$: $D = 128 > 0$ and $f_{xx} > 0 \\implies$ Local minima.`,
    syncStatus: 'local_only',
  },
  {
    id: 'f4',
    name: 'Vector_Calculus_Formula_Sheet_v2.pdf',
    folder: 'worksheets',
    subjectId: 'math201',
    subjectCode: 'MATH 201',
    fileSize: '840 KB',
    fileFormat: 'PDF',
    updatedAt: 'Mar 19, 2026',
    isOffline: true,
    downloadsCount: 312,
    description: 'Compact reference sheet for gradient, curl, divergence, spherical and cylindrical coordinate transforms.',
    keyConcepts: ['Green’s Theorem', 'Stokes’ Theorem', 'Divergence Theorem'],
    content: `# Vector Calculus Official Exam Formula Reference
**Department of Mathematics**

---

### Fundamental Theorems of Vector Analysis
1. **Gradient Theorem**: $\\int_C \\nabla f \\cdot d\\mathbf{r} = f(\\mathbf{r}(b)) - f(\\mathbf{r}(a))$.
2. **Green's Theorem**: $\\oint_C (P dx + Q dy) = \\iint_D (\\frac{\\partial Q}{\\partial x} - \\frac{\\partial P}{\\partial y}) dA$.
3. **Stokes' Theorem**: $\\oint_C \\mathbf{F} \\cdot d\\mathbf{r} = \\iint_S (\\nabla \\times \\mathbf{F}) \\cdot d\\mathbf{S}$.
4. **Divergence Theorem**: $\\iint_S \\mathbf{F} \\cdot d\\mathbf{S} = \\iiint_E (\\nabla \\cdot \\mathbf{F}) dV$.`,
    lastCachedAt: 'Mar 19, 2026',
    syncStatus: 'synced',
  },
  {
    id: 'f5',
    name: 'CS210_Cache_Simulation_Lab4_Manual.pdf',
    folder: 'worksheets',
    subjectId: 'cs210',
    subjectCode: 'CS 210',
    fileSize: '1.8 MB',
    fileFormat: 'PDF',
    updatedAt: 'Mar 17, 2026',
    isOffline: false,
    downloadsCount: 87,
    description: 'Instruction manual and test matrix for building an LRU direct-mapped and 4-way associative cache simulator.',
    keyConcepts: ['Cache Lines & Tags', 'Hit vs Miss Latency', 'Spatial & Temporal Locality'],
    content: `# CS 210 Lab 4: Cache Memory Organization & LRU Policy
**Instructor**: Dr. Marcus Vance

### Objectives
- Model address decomposition: 64-bit address into Tag, Set Index, and Block Offset.
- Measure miss rates for Direct-Mapped vs. 4-Way Set Associative caches under matrix transposition access patterns.`,
    syncStatus: 'local_only',
  },
  {
    id: 'f6',
    name: 'Physical_Chemistry_Thermodynamics_Summary.pdf',
    folder: 'readings',
    subjectId: 'sci108',
    subjectCode: 'CHEM 108',
    fileSize: '4.6 MB',
    fileFormat: 'PDF',
    updatedAt: 'Mar 08, 2026',
    isOffline: false,
    downloadsCount: 165,
    description: 'Selected chapter reading covering entropy changes in reversible adiabatic processes and Maxwell relations.',
    keyConcepts: ['First Law of Thermodynamics', 'Clapeyron Equation', 'Gibbs Free Energy'],
    content: `# CHEM 108: Thermodynamic Potentials Summary
**Instructor**: Dr. Sarah Al-Mansoor

### Fundamental Equations
- Internal Energy: $dU = T dS - P dV$
- Enthalpy: $dH = T dS + V dP$
- Helmholtz Free Energy: $dA = -S dT - P dV$
- Gibbs Free Energy: $dG = -S dT + V dP$

Spontaneity Criterion: For constant temperature and pressure, $\\Delta G \\le 0$.`,
    syncStatus: 'local_only',
  },
];

export const INITIAL_NOTICES: Notice[] = [
  {
    id: 'not-1',
    title: 'Midterm Examination Schedule & Hall Allocations Published',
    department: 'Academic Registry',
    author: 'Dean of Academic Affairs',
    date: 'Mar 19, 2026',
    timeAgo: '2 hours ago',
    isPinned: true,
    isUnread: true,
    priority: 'urgent',
    content: 'The official Spring 2026 Midterm Examination timetable is now released. Students must inspect desk assignments and reporting times at least 24 hours prior to exams. Physical student ID cards must be presented upon entering the examination hall.',
    attachmentName: 'Midterm_Exam_Schedule_Spring2026.pdf',
  },
  {
    id: 'not-2',
    title: 'Library Extended Hours During Study Week',
    department: 'University Library Services',
    author: 'Chief Librarian',
    date: 'Mar 18, 2026',
    timeAgo: '1 day ago',
    isPinned: true,
    isUnread: false,
    priority: 'general',
    content: 'Starting next Monday, the Central Computing Wing and Quiet Study Floors (3 & 4) will remain open 24 hours daily. Quiet zone policies will be strictly maintained.',
  },
  {
    id: 'not-3',
    title: 'CS 204: Tutorial Session Relocation to Room 402',
    department: 'Computing Department',
    author: 'Jordan Taylor (Class Prefect)',
    date: 'Mar 17, 2026',
    timeAgo: '2 days ago',
    isPinned: false,
    isUnread: true,
    priority: 'academic',
    relatedSubject: 'CS 204',
    content: 'Please take note that the Thursday tutorial for CS 204 has been shifted to Hall 402 due to projector maintenance in Room 3B.',
  },
  {
    id: 'not-4',
    title: 'Annual Student Research Symposium Call for Posters',
    department: 'Faculty of Science & Technology',
    author: 'Research Committee',
    date: 'Mar 14, 2026',
    timeAgo: '5 days ago',
    isPinned: false,
    isUnread: false,
    priority: 'academic',
    content: 'Undergraduate and Master’s candidates are invited to submit 300-word abstracts for poster presentations at the May 12th symposium. Submissions close April 15th.',
  },
];

export const SAMPLE_CHAT_HISTORY: ChatMessage[] = [
  {
    id: 'c1',
    sender: 'user',
    content: 'How does Dijkstra’s algorithm choose which vertex to visit next, and why can’t it handle negative weights?',
    timestamp: '10:14 AM',
  },
  {
    id: 'c2',
    sender: 'assistant',
    content: `Dijkstra's algorithm relies on a **greedy choice property**:

1. **Vertex Selection**: At each step, it extracts the unvisited vertex with the minimum known distance from the source using a Priority Queue (Min-Heap).
2. **Negative Edge Limitation**: The algorithm assumes that once a vertex is marked "visited", its shortest path is permanently finalized. If a negative weight edge exists later in the graph, it could decrease the distance to an already-finalized vertex, breaking this greedy invariant.

For graphs with negative edge weights without negative cycles, use the **Bellman-Ford algorithm** ($O(V \\cdot E)$) instead.`,
    timestamp: '10:14 AM',
  },
  {
    id: 'c3',
    sender: 'user',
    content: 'Can you generate a quick practice quiz to test my understanding of Graph Algorithms?',
    timestamp: '10:15 AM',
  },
  {
    id: 'c4',
    sender: 'assistant',
    content: 'Here is a 3-question knowledge check generated for CS 204. Tap "Start Quiz" below to test your recall.',
    timestamp: '10:15 AM',
    mode: 'quiz',
    interactiveData: {
      quizTitle: 'CS 204: Graph Algorithms Checkpoint',
    },
  },
];

export const SAMPLE_QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 'q1',
    question: 'What is the time complexity of Dijkstra’s algorithm implemented with a binary min-heap for a graph with V vertices and E edges?',
    options: ['O(V^2)', 'O((V + E) log V)', 'O(V * E)', 'O(E log E + V)'],
    correctAnswerIndex: 1,
    explanation: 'With a binary heap, each vertex extraction takes O(log V) and each decrease-key edge operation takes O(log V), yielding O((V + E) log V).',
  },
  {
    id: 'q2',
    question: 'Which traversal algorithm is used to find the shortest path in an unweighted graph?',
    options: ['Depth-First Search (DFS)', 'Breadth-First Search (BFS)', 'Prim’s Algorithm', 'Kruskal’s Algorithm'],
    correctAnswerIndex: 1,
    explanation: 'Breadth-First Search visits vertices in level-by-level radial distance order, ensuring the first time an unvisited vertex is reached corresponds to its shortest path in unweighted graphs.',
  },
  {
    id: 'q3',
    question: 'A directed graph has a valid topological ordering if and only if it is:',
    options: ['Strongly connected', 'A Directed Acyclic Graph (DAG)', 'Bipartite', 'A Complete Graph'],
    correctAnswerIndex: 1,
    explanation: 'Topological ordering requires that no cycle exists; any cycle creates circular dependency where no valid linear order is possible. Hence it must be a DAG.',
  },
];

export const SAMPLE_FLASHCARDS: Flashcard[] = [
  {
    id: 'fc1',
    topic: 'CS 204: Algorithms',
    prompt: 'What constitutes the greedy choice invariant in Dijkstra’s algorithm?',
    answer: 'The vertex with the minimum tentative distance in the priority queue is chosen next, under the guarantee that no shorter path can be discovered later when all edge weights are non-negative.',
  },
  {
    id: 'fc2',
    topic: 'MATH 201: Calculus',
    prompt: 'State Green’s Theorem in the plane relating a line integral to a double integral.',
    answer: '∮_C (L dx + M dy) = ∬_D (∂M/∂x - ∂L/∂y) dA, where C is a positively oriented, piecewise-smooth, simple closed curve enclosing region D.',
  },
  {
    id: 'fc3',
    topic: 'CS 210: Architecture',
    prompt: 'What is the difference between Spatial Locality and Temporal Locality?',
    answer: 'Temporal locality means recently accessed data will likely be accessed again soon. Spatial locality means memory locations physically adjacent to recent accesses will likely be accessed soon.',
  },
  {
    id: 'fc4',
    topic: 'CHEM 108: Kinetics',
    prompt: 'What does the activation energy (Ea) represent in the Arrhenius equation?',
    answer: 'The minimum kinetic energy that colliding reactant molecules must possess for a chemical transformation to successfully overcome the transition state barrier.',
  },
];
