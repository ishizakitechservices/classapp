export type TabType = 'home' | 'classes' | 'vault' | 'adom-ai' | 'notices';

export type UserRole = 'student' | 'class_manager' | 'class_admin' | 'platform_owner';

export type ThemeMode = 'system' | 'light' | 'dark';

export interface UserProfile {
  name: string;
  idNumber: string;
  email: string;
  role: UserRole;
  program: string;
  semester: string;
  avatarInitials: string;
  assignedClassIds?: string[]; // Classes this manager/admin is authorized to manage
}

export interface SyllabusItem {
  id: string;
  title: string;
  week: number;
  status: 'completed' | 'in_progress' | 'upcoming';
  date: string;
}

export interface ClassActivity {
  id: string;
  type: 'assignment' | 'lecture' | 'announcement';
  title: string;
  description: string;
  dueDate?: string;
  date: string;
  author: string;
  role: string;
}

export interface Subject {
  id: string;
  code: string;
  name: string;
  instructor: string;
  instructorEmail: string;
  room: string;
  schedule: string;
  progressPercent: number;
  totalLectures: number;
  attendedLectures: number;
  description: string;
  nextSession: string;
  syllabus: SyllabusItem[];
  activities: ClassActivity[];
}

export interface VaultFile {
  id: string;
  name: string;
  folder: 'slides' | 'worksheets' | 'past_papers' | 'readings' | 'notes';
  subjectId: string;
  subjectCode: string;
  fileSize: string;
  fileFormat: 'PDF' | 'DOCX' | 'PPTX' | 'ZIP';
  updatedAt: string;
  isOffline: boolean;
  downloadsCount: number;
  description: string;
  keyConcepts: string[];
  content?: string; // Stored readable content for offline document viewer
  lastCachedAt?: string;
  syncStatus?: 'synced' | 'local_only' | 'pending';
}

export interface Notice {
  id: string;
  title: string;
  department: string;
  author: string;
  date: string;
  timeAgo: string;
  isPinned: boolean;
  isUnread: boolean;
  priority: 'urgent' | 'academic' | 'general';
  content: string;
  relatedSubject?: string;
  attachmentName?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  content: string;
  timestamp: string;
  mode?: 'chat' | 'quiz' | 'flashcards' | 'notes' | 'explain';
  interactiveData?: {
    quizTitle?: string;
    questions?: QuizQuestion[];
    flashcards?: Flashcard[];
    summaryBullets?: string[];
  };
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
}

export interface QuizAttempt {
  id: string;
  quizTitle: string;
  subjectCode?: string;
  score: number;
  totalQuestions: number;
  percentage: number;
  timestamp: string;
  dateFormatted: string;
}

export interface Flashcard {
  id: string;
  topic: string;
  prompt: string;
  answer: string;
}

export interface ConnectedService {
  id: 'google_classroom' | 'google_drive';
  name: string;
  isConnected: boolean;
  accountEmail?: string;
  lastSyncedAt?: string;
  scopes: string[];
  autoSync: boolean;
}

export interface AppSettings {
  theme: ThemeMode;
  fontSize: 'small' | 'default' | 'large';
  reducedMotion: boolean;
  highContrast: boolean;
  offlineCacheEnabled: boolean;
  pushNotifications: boolean;
  quietHours: boolean;
}

/**
 * Role-Based Permission Checkers (Scoped to Class)
 */
export function canManageClass(role: UserRole, classId: string, assignedClassIds: string[] = []): boolean {
  if (role === 'platform_owner') return true;
  if (role === 'class_admin') return assignedClassIds.length === 0 || assignedClassIds.includes(classId);
  if (role === 'class_manager') return assignedClassIds.includes(classId);
  return false;
}

export function canPublishSchoolNotices(role: UserRole): boolean {
  return role === 'platform_owner' || role === 'class_admin';
}

export function canManageUsers(role: UserRole): boolean {
  return role === 'platform_owner';
}
