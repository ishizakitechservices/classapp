/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { SidebarNav } from './components/SidebarNav';
import { HomeScreen } from './components/screens/HomeScreen';
import { ClassesScreen } from './components/screens/ClassesScreen';
import { VaultScreen } from './components/screens/VaultScreen';
import { AdomAIScreen } from './components/screens/AdomAIScreen';
import { NoticesScreen } from './components/screens/NoticesScreen';
import { ProfileModal } from './components/screens/ProfileModal';
import { DocumentReaderModal } from './components/DocumentReaderModal';
import { OfflineIndicator } from './components/OfflineIndicator';

const AppContent: React.FC = () => {
  const { currentTab } = useApp();

  return (
    <div className="min-h-screen bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 flex flex-col antialiased transition-colors">
      {/* Top Header Bar */}
      <Header />

      {/* Main Container: Split with responsive desktop/tablet sidebar */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        {/* Tablet & Desktop Navigation Rail */}
        <SidebarNav />

        {/* Primary Viewport Content Area */}
        <main className="flex-1 min-w-0 px-4 py-5 md:px-8 md:py-6 max-w-5xl mx-auto w-full">
          {currentTab === 'home' && <HomeScreen />}
          {currentTab === 'classes' && <ClassesScreen />}
          {currentTab === 'vault' && <VaultScreen />}
          {currentTab === 'adom-ai' && <AdomAIScreen />}
          {currentTab === 'notices' && <NoticesScreen />}
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <BottomNav />

      {/* Modals & Persistent Overlays */}
      <ProfileModal />
      <DocumentReaderModal />
      <OfflineIndicator />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
