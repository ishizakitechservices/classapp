import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { VaultFile } from '../../types';
import {
  Search,
  FolderArchive,
  FileText,
  CheckCircle2,
  Sparkles,
  HardDrive,
  Eye,
  BookOpen,
} from 'lucide-react';

export const VaultScreen: React.FC = () => {
  const {
    vaultFiles,
    activeFileId,
    setActiveFileId,
    setActiveReaderFileId,
    toggleOffline,
    setCurrentTab,
    setActiveQuizOpen,
    totalOfflineStorageMB,
    clearOfflineStorage,
    storageQuota,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFolder, setSelectedFolder] = useState<string>('all');
  const [offlineOnly, setOfflineOnly] = useState(false);

  const folders = [
    { id: 'all', label: 'All Files' },
    { id: 'slides', label: 'Slides' },
    { id: 'worksheets', label: 'Worksheets' },
    { id: 'past_papers', label: 'Past Papers' },
    { id: 'readings', label: 'Readings' },
    { id: 'notes', label: 'Notes' },
  ];

  const filteredFiles = useMemo(() => {
    return vaultFiles.filter((file) => {
      const matchesSearch =
        file.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        file.subjectCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
        file.description.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesFolder = selectedFolder === 'all' || file.folder === selectedFolder;
      const matchesOffline = !offlineOnly || file.isOffline;

      return matchesSearch && matchesFolder && matchesOffline;
    });
  }, [vaultFiles, searchQuery, selectedFolder, offlineOnly]);

  const activeFile = vaultFiles.find((f) => f.id === activeFileId);

  return (
    <div className="space-y-6 pb-20 md:pb-8">
      {/* Vault Header & Storage Indicator */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-neutral-900 dark:text-white">
            Course Vault
          </h1>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Browse lecture slide decks, official past papers, formula sheets, and offline study materials.
          </p>
        </div>

        {/* Offline Cache status with quota */}
        <div className="flex items-center gap-3 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 px-3.5 py-2.5 rounded-xl text-xs shrink-0">
          <HardDrive className="w-4 h-4 text-neutral-400 shrink-0" />
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block">
                IndexedDB Cache
              </span>
              {storageQuota.percentageUsed > 0 && (
                <span className="text-[10px] text-neutral-400 font-mono">
                  ({storageQuota.percentageUsed}% quota)
                </span>
              )}
            </div>
            <span className="font-semibold text-neutral-900 dark:text-white font-mono tabular-nums">
              {totalOfflineStorageMB.toFixed(1)} MB saved
            </span>
          </div>
          {totalOfflineStorageMB > 0 && (
            <button
              onClick={clearOfflineStorage}
              className="text-[11px] text-neutral-500 hover:text-neutral-900 dark:hover:text-white underline ml-1"
              title="Clear cached files from IndexedDB"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Search and Filters */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search files by course code, topic, or file name..."
            className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl text-xs text-neutral-900 dark:text-white placeholder-neutral-400 focus:outline-none focus:ring-1 focus:ring-neutral-400"
          />
        </div>

        {/* Folder filter buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          {folders.map((f) => (
            <button
              key={f.id}
              onClick={() => setSelectedFolder(f.id)}
              className={`min-h-[36px] px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
                selectedFolder === f.id
                  ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 font-semibold'
                  : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              {f.label}
            </button>
          ))}

          <button
            onClick={() => setOfflineOnly(!offlineOnly)}
            className={`min-h-[36px] px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ml-auto ${
              offlineOnly
                ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 font-semibold'
                : 'border border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Saved Offline</span>
          </button>
        </div>
      </div>

      {/* Files Grid / List */}
      {filteredFiles.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl">
          <FolderArchive className="w-8 h-8 text-neutral-400 mx-auto mb-2" />
          <h3 className="text-sm font-semibold text-neutral-900 dark:text-white">
            No files found
          </h3>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Try adjusting your search query or folder filter.
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {filteredFiles.map((file) => (
            <div
              key={file.id}
              onClick={() => setActiveFileId(file.id)}
              className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl hover:border-neutral-400 dark:hover:border-neutral-700 cursor-pointer transition-colors flex items-center justify-between gap-3 group"
            >
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-neutral-900 dark:text-white truncate group-hover:underline">
                    {file.name}
                  </span>
                </div>
                <div className="text-[11px] text-neutral-500 dark:text-neutral-400 flex flex-wrap items-center gap-1.5 mt-1">
                  <span className="font-semibold text-neutral-700 dark:text-neutral-300">
                    {file.subjectCode}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono">{file.fileSize}</span>
                  <span aria-hidden="true">·</span>
                  <span>{file.updatedAt}</span>
                  <span aria-hidden="true">·</span>
                  <span className="capitalize">{file.folder.replace('_', ' ')}</span>
                </div>
              </div>

              {/* Action buttons on row */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveReaderFileId(file.id);
                  }}
                  className="min-h-[36px] px-2.5 py-1 rounded-lg text-xs font-medium border border-neutral-200 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors flex items-center gap-1"
                  title="Open and read file"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Read</span>
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleOffline(file.id);
                  }}
                  className={`min-h-[36px] px-2.5 py-1 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 ${
                    file.isOffline
                      ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900'
                      : 'border border-neutral-200 dark:border-neutral-700 text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
                  }`}
                  title={file.isOffline ? 'File saved to IndexedDB offline cache' : 'Save file for offline study'}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">
                    {file.isOffline ? 'Offline' : 'Save'}
                  </span>
                </button>

                <span className="text-xs font-mono px-2 py-1 rounded bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 uppercase font-semibold">
                  {file.fileFormat}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* File Detail Modal */}
      {activeFile && (
        <div
          className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl max-w-lg w-full p-6 space-y-4 shadow-xl">
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-neutral-500">
                  {activeFile.subjectCode} · {activeFile.folder.replace('_', ' ')}
                </span>
                <h3 className="text-base font-bold text-neutral-900 dark:text-white mt-1">
                  {activeFile.name}
                </h3>
              </div>
              <button
                onClick={() => setActiveFileId(null)}
                className="text-neutral-400 hover:text-neutral-900 dark:hover:text-white p-1 text-xs"
                aria-label="Close modal"
              >
                ✕
              </button>
            </div>

            <div className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
              {activeFile.description}
            </div>

            {/* Key concepts covered in file */}
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-500 block mb-1.5">
                Key Concepts Covered
              </span>
              <div className="flex flex-wrap gap-1.5">
                {activeFile.keyConcepts.map((concept, idx) => (
                  <span
                    key={idx}
                    className="text-xs text-neutral-700 dark:text-neutral-300 bg-neutral-100 dark:bg-neutral-800 px-2 py-0.5 rounded"
                  >
                    {concept}
                  </span>
                ))}
              </div>
            </div>

            {/* File metadata table */}
            <div className="grid grid-cols-3 gap-2 p-3 bg-neutral-50 dark:bg-neutral-800/50 rounded-lg text-xs font-mono">
              <div>
                <span className="text-neutral-400 text-[10px] block">Size</span>
                <span className="font-semibold text-neutral-900 dark:text-white">
                  {activeFile.fileSize}
                </span>
              </div>
              <div>
                <span className="text-neutral-400 text-[10px] block">Format</span>
                <span className="font-semibold text-neutral-900 dark:text-white">
                  {activeFile.fileFormat}
                </span>
              </div>
              <div>
                <span className="text-neutral-400 text-[10px] block">Status</span>
                <span className="font-semibold text-neutral-900 dark:text-white">
                  {activeFile.isOffline ? 'Offline Ready' : 'Online Only'}
                </span>
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex flex-col sm:flex-row gap-2 pt-2">
              <button
                onClick={() => {
                  const fid = activeFile.id;
                  setActiveFileId(null);
                  setActiveReaderFileId(fid);
                }}
                className="flex-1 min-h-[44px] px-4 py-2 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 hover:bg-neutral-800 dark:hover:bg-neutral-100 transition-colors"
              >
                <BookOpen className="w-4 h-4" />
                <span>Open Document Reader</span>
              </button>

              <button
                onClick={() => toggleOffline(activeFile.id)}
                className={`min-h-[44px] px-4 py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-colors ${
                  activeFile.isOffline
                    ? 'border border-neutral-300 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                    : 'border border-neutral-300 dark:border-neutral-700 text-neutral-900 dark:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{activeFile.isOffline ? 'Remove Offline' : 'Save Offline'}</span>
              </button>

              <button
                onClick={() => {
                  setActiveFileId(null);
                  setCurrentTab('adom-ai');
                  setActiveQuizOpen(true);
                }}
                className="min-h-[44px] px-3.5 py-2 border border-neutral-300 dark:border-neutral-700 text-neutral-900 dark:text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                title="Generate study questions from this file"
              >
                <Sparkles className="w-4 h-4" />
                <span>Quiz</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
