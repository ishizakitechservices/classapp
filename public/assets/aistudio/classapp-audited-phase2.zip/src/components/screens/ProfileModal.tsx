import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { UserRole, ThemeMode } from '../../types';
import {
  X,
  User,
  Moon,
  Sun,
  Monitor,
  HardDrive,
  Eye,
  Bell,
  ShieldCheck,
  Check,
  Link2,
  RefreshCw,
  LogOut,
  FolderSync,
} from 'lucide-react';

export const ProfileModal: React.FC = () => {
  const {
    isProfileOpen,
    setIsProfileOpen,
    userProfile,
    userRole,
    setUserRole,
    settings,
    updateSettings,
    setTheme,
    totalOfflineStorageMB,
    clearOfflineStorage,
    storageQuota,
    connectedServices,
    toggleConnectedService,
    resetToSampleData,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'profile' | 'services' | 'storage'>('profile');
  const [resetConfirm, setResetConfirm] = useState(false);

  if (!isProfileOpen) return null;

  const roles: Array<{ id: UserRole; label: string; desc: string }> = [
    { id: 'student', label: 'Student', desc: 'Standard learner account. Study materials, quizzes, and personal notes.' },
    { id: 'class_manager', label: 'Class Prefect', desc: 'Delegated student prefect with post permissions scoped to CS 204.' },
    { id: 'class_admin', label: 'Class Admin', desc: 'Faculty course director authorized for assigned courses.' },
    { id: 'platform_owner', label: 'Platform Owner', desc: 'Dean and administrator with institution-wide curriculum access.' },
  ];

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl max-w-lg w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl transition-colors">
        {/* Top Header */}
        <div className="p-4 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between shrink-0">
          <h2 id="modal-title" className="text-base font-bold text-neutral-900 dark:text-white">
            Account & Settings
          </h2>
          <button
            onClick={() => setIsProfileOpen(false)}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center text-neutral-400 hover:text-neutral-900 dark:hover:text-white rounded-lg"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Nav Tabs */}
        <div className="flex border-b border-neutral-100 dark:border-neutral-800 px-4 text-xs shrink-0">
          <button
            onClick={() => setActiveTab('profile')}
            className={`min-h-[40px] px-3 font-semibold border-b-2 transition-colors ${
              activeTab === 'profile'
                ? 'border-neutral-900 dark:border-white text-neutral-900 dark:text-white'
                : 'border-transparent text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            Profile & Roles
          </button>
          <button
            onClick={() => setActiveTab('services')}
            className={`min-h-[40px] px-3 font-semibold border-b-2 transition-colors ${
              activeTab === 'services'
                ? 'border-neutral-900 dark:border-white text-neutral-900 dark:text-white'
                : 'border-transparent text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            Connected Services
          </button>
          <button
            onClick={() => setActiveTab('storage')}
            className={`min-h-[40px] px-3 font-semibold border-b-2 transition-colors ${
              activeTab === 'storage'
                ? 'border-neutral-900 dark:border-white text-neutral-900 dark:text-white'
                : 'border-transparent text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            Offline & Storage
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Tab 1: Profile & Roles & Theme */}
          {activeTab === 'profile' && (
            <div className="space-y-6">
              {/* Account Card */}
              <div className="flex items-center gap-3.5 p-3.5 bg-neutral-50 dark:bg-neutral-800/50 rounded-xl border border-neutral-100 dark:border-neutral-800">
                <div className="w-12 h-12 rounded-full bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 flex items-center justify-center text-sm font-bold shrink-0">
                  {userProfile.avatarInitials}
                </div>
                <div className="min-w-0">
                  <h3 className="text-sm font-bold text-neutral-900 dark:text-white truncate">
                    {userProfile.name}
                  </h3>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 truncate">
                    {userProfile.email}
                  </p>
                  <p className="text-[11px] font-mono text-neutral-400 mt-0.5">
                    {userProfile.idNumber} · {userProfile.program}
                  </p>
                </div>
              </div>

              {/* Exact Phase 6 Role Selector */}
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-500 mb-2">
                  Role Assignment (Class Scoping)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {roles.map((r) => {
                    const isSelected = userRole === r.id;
                    return (
                      <button
                        key={r.id}
                        onClick={() => setUserRole(r.id)}
                        className={`p-3 rounded-xl border text-left transition-colors flex flex-col justify-between ${
                          isSelected
                            ? 'border-neutral-900 dark:border-white bg-neutral-900 text-white dark:bg-white dark:text-neutral-900'
                            : 'border-neutral-200 dark:border-neutral-800 hover:border-neutral-400 text-neutral-700 dark:text-neutral-300'
                        }`}
                      >
                        <div>
                          <div className="font-bold">{r.label}</div>
                          <div
                            className={`text-[11px] mt-1 line-clamp-2 ${
                              isSelected ? 'text-neutral-300 dark:text-neutral-600' : 'text-neutral-400'
                            }`}
                          >
                            {r.desc}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Appearance Controls */}
              <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800">
                <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-500 mb-2">
                  Theme Preference
                </label>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  {(['light', 'dark', 'system'] as ThemeMode[]).map((mode) => (
                    <button
                      key={mode}
                      onClick={() => setTheme(mode)}
                      className={`min-h-[44px] px-2 py-2 rounded-xl border flex flex-col items-center justify-center gap-1 transition-colors ${
                        settings.theme === mode
                          ? 'border-neutral-900 dark:border-white bg-neutral-100 dark:bg-neutral-800 font-semibold text-neutral-900 dark:text-white'
                          : 'border-neutral-200 dark:border-neutral-800 text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
                      }`}
                    >
                      {mode === 'light' && <Sun className="w-4 h-4" />}
                      {mode === 'dark' && <Moon className="w-4 h-4" />}
                      {mode === 'system' && <Monitor className="w-4 h-4" />}
                      <span className="capitalize text-[11px]">{mode}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Accessibility Settings */}
              <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 space-y-3">
                <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-500">
                  Accessibility & Display
                </label>

                {/* Font Scale */}
                <div className="flex items-center justify-between text-xs">
                  <span className="text-neutral-700 dark:text-neutral-300">Text Scaling</span>
                  <div className="flex gap-1">
                    {(['small', 'default', 'large'] as const).map((sz) => (
                      <button
                        key={sz}
                        onClick={() => updateSettings({ fontSize: sz })}
                        className={`px-2.5 py-1 text-xs rounded border capitalize transition-colors ${
                          settings.fontSize === sz
                            ? 'border-neutral-900 dark:border-white bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 font-bold'
                            : 'border-neutral-200 dark:border-neutral-800 text-neutral-500'
                        }`}
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Reduced Motion */}
                <div className="flex items-center justify-between text-xs pt-1">
                  <span className="text-neutral-700 dark:text-neutral-300">Reduced Motion</span>
                  <button
                    onClick={() => updateSettings({ reducedMotion: !settings.reducedMotion })}
                    className={`min-h-[32px] px-3 rounded-full text-[11px] font-medium border transition-colors ${
                      settings.reducedMotion
                        ? 'border-neutral-900 dark:border-white bg-neutral-900 text-white dark:bg-white dark:text-neutral-900'
                        : 'border-neutral-200 dark:border-neutral-800 text-neutral-500'
                    }`}
                  >
                    {settings.reducedMotion ? 'Enabled' : 'Off'}
                  </button>
                </div>

                {/* High Contrast */}
                <div className="flex items-center justify-between text-xs pt-1">
                  <span className="text-neutral-700 dark:text-neutral-300">High Contrast</span>
                  <button
                    onClick={() => updateSettings({ highContrast: !settings.highContrast })}
                    className={`min-h-[32px] px-3 rounded-full text-[11px] font-medium border transition-colors ${
                      settings.highContrast
                        ? 'border-neutral-900 dark:border-white bg-neutral-900 text-white dark:bg-white dark:text-neutral-900'
                        : 'border-neutral-200 dark:border-neutral-800 text-neutral-500'
                    }`}
                  >
                    {settings.highContrast ? 'Enabled' : 'Off'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: Connected Services (Phase 5.5 Google Drive & Classroom) */}
          {activeTab === 'services' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-neutral-900 dark:text-white">
                  Google Workspace Integrations
                </h3>
                <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5 leading-relaxed">
                  Authorize once to sync your course assignments, lecture folders, and official course materials. No client secrets are embedded in the browser.
                </p>
              </div>

              <div className="space-y-3 pt-2">
                {connectedServices.map((svc) => (
                  <div
                    key={svc.id}
                    className="p-4 bg-neutral-50 dark:bg-neutral-800/50 rounded-xl border border-neutral-200 dark:border-neutral-700 space-y-3"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-neutral-900 dark:text-white">
                            {svc.name}
                          </span>
                          <span
                            className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                              svc.isConnected
                                ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900'
                                : 'bg-neutral-200 dark:bg-neutral-700 text-neutral-600 dark:text-neutral-400'
                            }`}
                          >
                            {svc.isConnected ? 'Connected' : 'Disconnected'}
                          </span>
                        </div>
                        <p className="text-[11px] text-neutral-500 mt-1">
                          {svc.id === 'google_classroom'
                            ? 'Sync courses, coursework deadlines, and instructor announcements.'
                            : 'Sync lecture slide decks and worksheets directly to your Vault.'}
                        </p>
                      </div>

                      <button
                        onClick={() => toggleConnectedService(svc.id)}
                        className={`min-h-[36px] px-3 rounded-lg text-xs font-semibold transition-colors shrink-0 ${
                          svc.isConnected
                            ? 'border border-neutral-300 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                            : 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 hover:opacity-90'
                        }`}
                      >
                        {svc.isConnected ? 'Disconnect' : 'Connect'}
                      </button>
                    </div>

                    {/* Scopes disclosure */}
                    <div className="pt-2 border-t border-neutral-200/60 dark:border-neutral-700/60 text-[10px] text-neutral-400 font-mono space-y-0.5">
                      <div className="font-sans font-medium text-neutral-500">Requested Scopes:</div>
                      {svc.scopes.map((s, idx) => (
                        <div key={idx} className="truncate">
                          · {s}
                        </div>
                      ))}
                    </div>

                    {svc.isConnected && (
                      <div className="text-[11px] text-neutral-500 flex items-center justify-between">
                        <span>Account: {svc.accountEmail}</span>
                        <span>Synced: {svc.lastSyncedAt}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tab 3: Offline & Storage (Phase 5.1 & 5.2) */}
          {activeTab === 'storage' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-neutral-900 dark:text-white">
                  IndexedDB & Cache Storage
                </h3>
                <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                  ClassApp keeps course records, documents, and quiz history cached locally for instant offline study.
                </p>
              </div>

              {/* Quota details */}
              <div className="p-4 bg-neutral-50 dark:bg-neutral-800/50 rounded-xl border border-neutral-200 dark:border-neutral-700 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-neutral-600 dark:text-neutral-400">Cached Lecture Documents</span>
                  <span className="font-mono font-bold text-neutral-900 dark:text-white">
                    {totalOfflineStorageMB.toFixed(1)} MB
                  </span>
                </div>

                {storageQuota.quotaMB > 0 && (
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-neutral-600 dark:text-neutral-400">Total Browser Quota Allocated</span>
                    <span className="font-mono font-semibold text-neutral-900 dark:text-white">
                      {storageQuota.usageMB.toFixed(1)} MB / {storageQuota.quotaMB.toLocaleString()} MB ({storageQuota.percentageUsed}%)
                    </span>
                  </div>
                )}

                <div className="pt-2 flex gap-2">
                  <button
                    onClick={clearOfflineStorage}
                    disabled={totalOfflineStorageMB === 0}
                    className="flex-1 min-h-[38px] px-3 rounded-lg border border-neutral-300 dark:border-neutral-700 text-xs font-semibold text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 disabled:opacity-40 transition-colors"
                  >
                    Clear Offline Files
                  </button>

                  <button
                    onClick={() => {
                      if (!resetConfirm) {
                        setResetConfirm(true);
                      } else {
                        resetToSampleData();
                        setResetConfirm(false);
                      }
                    }}
                    className="min-h-[38px] px-3 rounded-lg border border-neutral-300 dark:border-neutral-700 text-xs font-medium text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                  >
                    {resetConfirm ? 'Confirm Reset All Data?' : 'Reset All to Defaults'}
                  </button>
                </div>
              </div>

              {/* Service Worker status */}
              <div className="p-3 bg-neutral-100 dark:bg-neutral-800 rounded-xl text-xs flex items-center justify-between">
                <div>
                  <span className="font-bold text-neutral-900 dark:text-white block">
                    Service Worker Status
                  </span>
                  <span className="text-[11px] text-neutral-500">
                    Precached application shell active
                  </span>
                </div>
                <span className="text-[11px] font-mono font-semibold text-neutral-700 dark:text-neutral-300">
                  Active
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between shrink-0 bg-neutral-50/50 dark:bg-neutral-900/50">
          <div className="text-[11px] text-neutral-400">
            ClassApp v1.1 · Phase 2 Offline Ready
          </div>
          <button
            onClick={() => setIsProfileOpen(false)}
            className="min-h-[38px] px-4 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 rounded-lg text-xs font-semibold"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
