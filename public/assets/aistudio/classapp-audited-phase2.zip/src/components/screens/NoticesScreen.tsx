import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Notice } from '../../types';
import {
  Search,
  Bell,
  Pin,
  Check,
  PlusCircle,
  FileText,
  X,
} from 'lucide-react';

export const NoticesScreen: React.FC = () => {
  const {
    notices,
    activeNoticeId,
    setActiveNoticeId,
    toggleNoticeRead,
    toggleNoticePin,
    addNotice,
    unreadNoticesCount,
    canPublishNotices,
    userProfile,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'unread' | 'pinned' | 'urgent'>('all');

  // Staff post circular modal state
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDepartment, setNewDepartment] = useState('Academic Affairs');
  const [newPriority, setNewPriority] = useState<Notice['priority']>('academic');
  const [newContent, setNewContent] = useState('');

  const filteredNotices = useMemo(() => {
    return notices.filter((n) => {
      const matchesSearch =
        n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        n.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
        n.department.toLowerCase().includes(searchQuery.toLowerCase());

      if (!matchesSearch) return false;

      if (filterType === 'unread') return n.isUnread;
      if (filterType === 'pinned') return n.isPinned;
      if (filterType === 'urgent') return n.priority === 'urgent';
      return true;
    });
  }, [notices, searchQuery, filterType]);

  const activeNotice = notices.find((n) => n.id === activeNoticeId);

  const handleCreateNotice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;

    await addNotice({
      title: newTitle.trim(),
      department: newDepartment,
      author: userProfile.name,
      date: new Date().toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }),
      isPinned: newPriority === 'urgent',
      isUnread: true,
      priority: newPriority,
      content: newContent.trim(),
    });

    setNewTitle('');
    setNewContent('');
    setShowCreateModal(false);
  };

  return (
    <div className="space-y-6 pb-20 md:pb-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-neutral-900 dark:text-white">
            Notices & Circulars
          </h1>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Official university bulletins, department timetable notices, and class updates.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          {canPublishNotices && (
            <button
              onClick={() => setShowCreateModal(true)}
              className="min-h-[38px] px-3.5 py-1.5 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 rounded-lg text-xs font-semibold hover:bg-neutral-800 dark:hover:bg-neutral-100 transition-colors flex items-center gap-1.5"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>Post Circular</span>
            </button>
          )}

          {unreadNoticesCount > 0 && (
            <div className="text-xs text-neutral-600 dark:text-neutral-400 bg-neutral-100 dark:bg-neutral-800 px-3 py-1.5 rounded-lg font-mono">
              {unreadNoticesCount} unread
            </div>
          )}
        </div>
      </div>

      {/* Search and Filters */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search circulars by keyword, department, or title..."
            className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl text-xs text-neutral-900 dark:text-white placeholder-neutral-400 focus:outline-none focus:ring-1 focus:ring-neutral-400"
          />
        </div>

        {/* Filter buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <button
            onClick={() => setFilterType('all')}
            className={`min-h-[36px] px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
              filterType === 'all'
                ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 font-semibold'
                : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            All Notices
          </button>
          <button
            onClick={() => setFilterType('unread')}
            className={`min-h-[36px] px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
              filterType === 'unread'
                ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 font-semibold'
                : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            Unread Only ({notices.filter((n) => n.isUnread).length})
          </button>
          <button
            onClick={() => setFilterType('pinned')}
            className={`min-h-[36px] px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
              filterType === 'pinned'
                ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 font-semibold'
                : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            Pinned Bulletins
          </button>
          <button
            onClick={() => setFilterType('urgent')}
            className={`min-h-[36px] px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
              filterType === 'urgent'
                ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 font-semibold'
                : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            Urgent Only
          </button>
        </div>
      </div>

      {/* Notices List */}
      {filteredNotices.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl">
          <Bell className="w-8 h-8 text-neutral-400 mx-auto mb-2" />
          <h3 className="text-sm font-semibold text-neutral-900 dark:text-white">
            No notices match your criteria
          </h3>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Check back later or adjust your search filter.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredNotices.map((notice) => (
            <div
              key={notice.id}
              onClick={() => {
                setActiveNoticeId(notice.id);
                if (notice.isUnread) toggleNoticeRead(notice.id);
              }}
              className={`p-5 bg-white dark:bg-neutral-900 border rounded-xl hover:border-neutral-400 dark:hover:border-neutral-700 cursor-pointer transition-colors relative group ${
                notice.isUnread
                  ? 'border-neutral-300 dark:border-neutral-700 shadow-xs'
                  : 'border-neutral-200 dark:border-neutral-800'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    {notice.isPinned && (
                      <span className="flex items-center gap-1 text-[10px] font-mono uppercase text-neutral-500 font-semibold">
                        <Pin className="w-3 h-3 rotate-45" />
                        Pinned
                      </span>
                    )}
                    {notice.priority === 'urgent' && (
                      <span className="text-[10px] font-mono uppercase font-bold text-neutral-900 dark:text-white">
                        Urgent
                      </span>
                    )}
                    <span className="text-[11px] text-neutral-400">
                      {notice.department}
                    </span>
                  </div>

                  <h2
                    className={`text-sm tracking-tight group-hover:underline ${
                      notice.isUnread
                        ? 'font-bold text-neutral-900 dark:text-white'
                        : 'font-medium text-neutral-700 dark:text-neutral-300'
                    }`}
                  >
                    {notice.title}
                  </h2>

                  <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-2 line-clamp-2 leading-relaxed">
                    {notice.content}
                  </p>

                  <div className="mt-3 flex items-center gap-2 text-[11px] text-neutral-400">
                    <span>{notice.author}</span>
                    <span aria-hidden="true">·</span>
                    <span>{notice.timeAgo}</span>
                    {notice.attachmentName && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="flex items-center gap-1 text-neutral-700 dark:text-neutral-300">
                          <FileText className="w-3 h-3" />
                          Attachment
                        </span>
                      </>
                    )}
                  </div>
                </div>

                {/* Mark read / unread and pin toggle button */}
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleNoticeRead(notice.id);
                    }}
                    className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-lg text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                    title={notice.isUnread ? 'Mark as read' : 'Mark as unread'}
                  >
                    {notice.isUnread ? (
                      <div className="w-2.5 h-2.5 rounded-full bg-neutral-900 dark:bg-white" />
                    ) : (
                      <Check className="w-4 h-4" />
                    )}
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleNoticePin(notice.id);
                    }}
                    className={`min-h-[38px] min-w-[38px] flex items-center justify-center rounded-lg transition-colors ${
                      notice.isPinned
                        ? 'text-neutral-900 dark:text-white'
                        : 'text-neutral-300 hover:text-neutral-600 dark:hover:text-neutral-400'
                    }`}
                    title={notice.isPinned ? 'Unpin' : 'Pin notice'}
                  >
                    <Pin className="w-4 h-4 rotate-45" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Staff Post Circular Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-neutral-900 dark:text-white">
                Publish Official Campus Circular
              </h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-neutral-400 hover:text-neutral-900 dark:hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateNotice} className="space-y-3 text-xs">
              <div>
                <label className="block text-neutral-700 dark:text-neutral-300 mb-1 font-medium">
                  Title
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Library Hours Revised for Final Exams"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full p-2.5 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-neutral-700 dark:text-neutral-300 mb-1 font-medium">
                    Department
                  </label>
                  <select
                    value={newDepartment}
                    onChange={(e) => setNewDepartment(e.target.value)}
                    className="w-full p-2 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-white"
                  >
                    <option value="Academic Registry">Academic Registry</option>
                    <option value="Library Services">Library Services</option>
                    <option value="Computing Department">Computing Department</option>
                    <option value="Faculty of Science">Faculty of Science</option>
                  </select>
                </div>

                <div>
                  <label className="block text-neutral-700 dark:text-neutral-300 mb-1 font-medium">
                    Priority
                  </label>
                  <select
                    value={newPriority}
                    onChange={(e: any) => setNewPriority(e.target.value)}
                    className="w-full p-2 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-white"
                  >
                    <option value="academic">Academic</option>
                    <option value="urgent">Urgent Bulletin</option>
                    <option value="general">General Notice</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-neutral-700 dark:text-neutral-300 mb-1 font-medium">
                  Full Announcement Content
                </label>
                <textarea
                  rows={4}
                  required
                  placeholder="Provide circular text and instructions..."
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  className="w-full p-2.5 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-white resize-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-3 py-2 rounded-lg text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 rounded-lg font-semibold hover:bg-neutral-800 dark:hover:bg-neutral-100"
                >
                  Publish Notice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Notice Detail Modal */}
      {activeNotice && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl max-w-lg w-full p-6 space-y-4 shadow-xl">
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-neutral-500">
                  {activeNotice.department} · {activeNotice.date}
                </span>
                <h3 className="text-base font-bold text-neutral-900 dark:text-white mt-1">
                  {activeNotice.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveNoticeId(null)}
                className="text-neutral-400 hover:text-neutral-900 dark:hover:text-white p-1 text-xs"
              >
                ✕
              </button>
            </div>

            <div className="text-xs text-neutral-700 dark:text-neutral-300 leading-relaxed whitespace-pre-line border-t border-b border-neutral-100 dark:border-neutral-800 py-3">
              {activeNotice.content}
            </div>

            {activeNotice.attachmentName && (
              <div className="p-3 bg-neutral-50 dark:bg-neutral-800/50 rounded-lg flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 truncate">
                  <FileText className="w-4 h-4 text-neutral-500 shrink-0" />
                  <span className="font-semibold text-neutral-900 dark:text-white truncate">
                    {activeNotice.attachmentName}
                  </span>
                </div>
                <button className="text-[11px] font-semibold text-neutral-900 dark:text-white hover:underline shrink-0 ml-2">
                  Download
                </button>
              </div>
            )}

            <div className="flex items-center justify-between pt-2 text-xs">
              <span className="text-neutral-400 text-[11px]">
                Authorized by {activeNotice.author}
              </span>
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    toggleNoticeRead(activeNotice.id);
                  }}
                  className="min-h-[40px] px-3 rounded-lg border border-neutral-300 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800"
                >
                  {activeNotice.isUnread ? 'Mark Read' : 'Mark Unread'}
                </button>
                <button
                  onClick={() => setActiveNoticeId(null)}
                  className="min-h-[40px] px-4 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 rounded-lg font-semibold"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
