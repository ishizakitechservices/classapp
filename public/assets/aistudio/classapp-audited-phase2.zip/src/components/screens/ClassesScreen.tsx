import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Subject, ClassActivity } from '../../types';
import {
  ChevronRight,
  BookOpen,
  Calendar,
  User,
  MapPin,
  Clock,
  PlusCircle,
  CheckCircle,
  FileText,
  AlertCircle,
  Sparkles,
  Eye,
} from 'lucide-react';

export const ClassesScreen: React.FC = () => {
  const {
    subjects,
    activeSubjectId,
    setActiveSubjectId,
    userRole,
    userProfile,
    canManageCurrentClass,
    addSubjectActivity,
    vaultFiles,
    setActiveFileId,
    setActiveReaderFileId,
    setCurrentTab,
    setActiveQuizOpen,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'resources' | 'activity' | 'syllabus'>('resources');

  // Modal / form state for posting announcement
  const [showAddActivityModal, setShowAddActivityModal] = useState(false);
  const [newActivityTitle, setNewActivityTitle] = useState('');
  const [newActivityDesc, setNewActivityDesc] = useState('');
  const [newActivityType, setNewActivityType] = useState<'assignment' | 'lecture' | 'announcement'>('announcement');

  const selectedSubject = subjects.find((s) => s.id === activeSubjectId);

  const handlePostActivity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSubject || !newActivityTitle.trim()) return;

    await addSubjectActivity(selectedSubject.id, {
      title: newActivityTitle.trim(),
      description: newActivityDesc.trim() || 'No additional instructions provided.',
      type: newActivityType,
      author: userProfile.name,
      role: userRole === 'class_manager' ? 'Class Prefect' : userRole === 'class_admin' ? 'Course Director' : 'Administrator',
    });

    setNewActivityTitle('');
    setNewActivityDesc('');
    setShowAddActivityModal(false);
  };

  // If a subject is selected, render nested subject detail view
  if (selectedSubject) {
    const subjectFiles = vaultFiles.filter((f) => f.subjectId === selectedSubject.id);
    const isAuthorizedManager = canManageCurrentClass(selectedSubject.id);

    return (
      <div className="space-y-6 pb-20 md:pb-8">
        {/* Subject Header Card */}
        <section className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-5">
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs text-neutral-500 dark:text-neutral-400 mb-1">
                <span className="font-mono font-bold text-neutral-900 dark:text-white">
                  {selectedSubject.code}
                </span>
                <span aria-hidden="true">·</span>
                <span>{selectedSubject.schedule}</span>
              </div>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-neutral-900 dark:text-white">
                {selectedSubject.name}
              </h1>
              <p className="text-xs text-neutral-600 dark:text-neutral-300 mt-2 max-w-2xl leading-relaxed">
                {selectedSubject.description}
              </p>
            </div>

            {/* Quick stats */}
            <div className="flex sm:flex-col items-center sm:items-end gap-3 sm:gap-1 text-xs shrink-0">
              <div className="text-right">
                <span className="text-xs text-neutral-500 dark:text-neutral-400 block">
                  Syllabus Completed
                </span>
                <span className="text-base font-bold text-neutral-900 dark:text-white font-mono tabular-nums">
                  {selectedSubject.progressPercent}%
                </span>
              </div>
              <div className="text-neutral-400 dark:text-neutral-500 text-[11px]">
                {selectedSubject.attendedLectures}/{selectedSubject.totalLectures} lectures attended
              </div>
            </div>
          </div>

          {/* Quick info row */}
          <div className="mt-4 pt-4 border-t border-neutral-100 dark:border-neutral-800 flex flex-wrap items-center gap-4 text-xs text-neutral-600 dark:text-neutral-400">
            <span className="flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-neutral-400" />
              {selectedSubject.instructor}
            </span>
            <span className="flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-neutral-400" />
              {selectedSubject.room}
            </span>
            <span className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-neutral-400" />
              Next: {selectedSubject.nextSession}
            </span>
          </div>

          {/* Class-Scoped Management Tools (Strictly enforced by role & class assignment) */}
          {isAuthorizedManager && (
            <div className="mt-4 pt-4 border-t border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-800/60 -mx-5 -mb-5 p-4 rounded-b-xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-neutral-900 dark:text-white">
                    {userRole === 'class_manager'
                      ? 'Class Prefect Console'
                      : userRole === 'class_admin'
                      ? 'Course Director Console'
                      : 'Platform Administration Console'}
                  </span>
                  <span className="text-[11px] text-neutral-500 dark:text-neutral-400 hidden sm:inline">
                    (Authorized for {selectedSubject.code})
                  </span>
                </div>
                <button
                  onClick={() => setShowAddActivityModal(true)}
                  className="min-h-[36px] px-3.5 py-1.5 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 rounded-lg text-xs font-medium hover:bg-neutral-800 dark:hover:bg-neutral-100 transition-colors flex items-center gap-1.5 self-start sm:self-auto"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>Post Class Update</span>
                </button>
              </div>
            </div>
          )}
        </section>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 border-b border-neutral-200 dark:border-neutral-800 pb-2">
          <button
            onClick={() => setActiveTab('resources')}
            className={`min-h-[44px] px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'resources'
                ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800'
            }`}
          >
            Resources & Lecture Notes ({subjectFiles.length})
          </button>
          <button
            onClick={() => setActiveTab('activity')}
            className={`min-h-[44px] px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'activity'
                ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800'
            }`}
          >
            Class Activity ({selectedSubject.activities.length})
          </button>
          <button
            onClick={() => setActiveTab('syllabus')}
            className={`min-h-[44px] px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'syllabus'
                ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800'
            }`}
          >
            Syllabus Milestones
          </button>
        </div>

        {/* Tab 1: Resources */}
        {activeTab === 'resources' && (
          <div className="space-y-3">
            {subjectFiles.length === 0 ? (
              <div className="p-8 text-center text-xs text-neutral-500 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl">
                No files uploaded specifically for this subject yet.
              </div>
            ) : (
              subjectFiles.map((file) => (
                <div
                  key={file.id}
                  onClick={() => setActiveReaderFileId(file.id)}
                  className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl hover:border-neutral-400 dark:hover:border-neutral-700 cursor-pointer transition-colors flex items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <div className="text-xs font-semibold text-neutral-900 dark:text-white truncate">
                      {file.name}
                    </div>
                    <div className="text-[11px] text-neutral-500 dark:text-neutral-400 flex items-center gap-1.5 mt-0.5">
                      <span className="font-mono">{file.fileSize}</span>
                      <span aria-hidden="true">·</span>
                      <span>Updated {file.updatedAt}</span>
                      {file.isOffline && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-neutral-900 dark:text-white font-medium">Cached Offline</span>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveReaderFileId(file.id);
                      }}
                      className="min-h-[36px] px-2.5 py-1 text-xs border border-neutral-300 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-md transition-colors flex items-center gap-1 text-neutral-700 dark:text-neutral-300 font-medium"
                      title="Read file contents"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Read</span>
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setCurrentTab('adom-ai');
                        setActiveQuizOpen(true);
                      }}
                      className="min-h-[36px] px-2.5 py-1 text-xs border border-neutral-300 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-md transition-colors flex items-center gap-1 text-neutral-700 dark:text-neutral-300 font-medium"
                      title="Practice quiz on this document"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Quiz</span>
                    </button>
                    <span className="text-xs font-mono px-2 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 uppercase">
                      {file.fileFormat}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Tab 2: Activity */}
        {activeTab === 'activity' && (
          <div className="space-y-3">
            {selectedSubject.activities.map((act) => (
              <div
                key={act.id}
                className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-neutral-500 dark:text-neutral-400 block mb-0.5">
                      {act.type} · {act.date}
                    </span>
                    <h3 className="text-xs font-bold text-neutral-900 dark:text-white">
                      {act.title}
                    </h3>
                  </div>
                  {act.dueDate && (
                    <span className="text-[11px] font-mono text-neutral-700 dark:text-neutral-300 bg-neutral-100 dark:bg-neutral-800 px-2 py-0.5 rounded shrink-0">
                      Due: {act.dueDate}
                    </span>
                  )}
                </div>
                <p className="text-xs text-neutral-600 dark:text-neutral-300 mt-2 leading-relaxed">
                  {act.description}
                </p>
                <div className="mt-3 pt-2 border-t border-neutral-100 dark:border-neutral-800 text-[11px] text-neutral-400">
                  Posted by {act.author} ({act.role})
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Tab 3: Syllabus */}
        {activeTab === 'syllabus' && (
          <div className="space-y-2">
            {selectedSubject.syllabus.map((item) => (
              <div
                key={item.id}
                className="p-3.5 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl flex items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 text-[11px] font-mono font-bold ${
                      item.status === 'completed'
                        ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900'
                        : item.status === 'in_progress'
                        ? 'border border-neutral-900 text-neutral-900 dark:border-white dark:text-white'
                        : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-400'
                    }`}
                  >
                    W{item.week}
                  </div>
                  <div className="min-w-0">
                    <span className="font-medium text-neutral-900 dark:text-white block truncate">
                      {item.title}
                    </span>
                    <span className="text-[11px] text-neutral-500 dark:text-neutral-400">
                      Scheduled for {item.date}
                    </span>
                  </div>
                </div>

                <span className="text-[11px] font-mono uppercase text-neutral-500 shrink-0">
                  {item.status.replace('_', ' ')}
                </span>
              </div>
            ))}
          </div>
        )}

        {/* Teacher Post Modal */}
        {showAddActivityModal && (
          <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl max-w-md w-full p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-neutral-900 dark:text-white">
                  Post Class Announcement / Task
                </h3>
                <button
                  onClick={() => setShowAddActivityModal(false)}
                  className="text-xs text-neutral-400 hover:text-neutral-900 dark:hover:text-white"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handlePostActivity} className="space-y-3 text-xs">
                <div>
                  <label className="block text-neutral-700 dark:text-neutral-300 mb-1 font-medium">
                    Type
                  </label>
                  <select
                    value={newActivityType}
                    onChange={(e: any) => setNewActivityType(e.target.value)}
                    className="w-full p-2 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-white"
                  >
                    <option value="announcement">Announcement</option>
                    <option value="assignment">Assignment / Problem Set</option>
                    <option value="lecture">Lecture Slide Notification</option>
                  </select>
                </div>

                <div>
                  <label className="block text-neutral-700 dark:text-neutral-300 mb-1 font-medium">
                    Title
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Tutorial Rescheduled to Room 301"
                    value={newActivityTitle}
                    onChange={(e) => setNewActivityTitle(e.target.value)}
                    className="w-full p-2 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-neutral-700 dark:text-neutral-300 mb-1 font-medium">
                    Details / Instructions
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Provide details for students..."
                    value={newActivityDesc}
                    onChange={(e) => setNewActivityDesc(e.target.value)}
                    className="w-full p-2 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-white resize-none"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAddActivityModal(false)}
                    className="px-3 py-2 rounded-lg text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 rounded-lg font-semibold hover:bg-neutral-800 dark:hover:bg-neutral-100"
                  >
                    Publish Update
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Primary Classes list view
  return (
    <div className="space-y-6 pb-20 md:pb-8">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-neutral-900 dark:text-white">
          Enrolled Classes
        </h1>
        <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
          Select any course to view syllabus milestones, lecture slide decks, and class activities.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {subjects.map((subject) => {
          const isManaged = canManageCurrentClass(subject.id);

          return (
            <div
              key={subject.id}
              onClick={() => setActiveSubjectId(subject.id)}
              className="p-5 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl hover:border-neutral-400 dark:hover:border-neutral-700 cursor-pointer transition-colors flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-neutral-900 dark:text-white">
                      {subject.code}
                    </span>
                    {isManaged && (
                      <span className="text-[10px] font-mono uppercase bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 px-1.5 py-0.5 rounded">
                        Managed
                      </span>
                    )}
                  </div>
                  <span className="text-[11px] font-mono tabular-nums text-neutral-500 dark:text-neutral-400">
                    {subject.progressPercent}% complete
                  </span>
                </div>

                <h2 className="text-base font-bold text-neutral-900 dark:text-white group-hover:underline">
                  {subject.name}
                </h2>

                <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-2 line-clamp-2">
                  {subject.description}
                </p>
              </div>

              <div className="mt-4 pt-4 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400">
                <div className="truncate pr-2">
                  <span>{subject.instructor}</span>
                  <span aria-hidden="true" className="mx-1.5">
                    ·
                  </span>
                  <span>{subject.room}</span>
                </div>
                <ChevronRight className="w-4 h-4 text-neutral-400 group-hover:text-neutral-900 dark:group-hover:text-white transition-colors shrink-0" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
