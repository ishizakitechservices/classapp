import React from 'react';
import { useApp } from '../context/AppContext';
import { ArrowLeft, Moon, Sun, Monitor, WifiOff } from 'lucide-react';
import { UserRole } from '../types';
import { PWAInstallButton } from './PWAInstallButton';

export const Header: React.FC = () => {
  const {
    activeSubjectId,
    setActiveSubjectId,
    subjects,
    userRole,
    setUserRole,
    userProfile,
    setIsProfileOpen,
    settings,
    setTheme,
    currentTab,
    isOnline,
  } = useApp();

  const activeSubject = subjects.find((s) => s.id === activeSubjectId);

  const cycleTheme = () => {
    if (settings.theme === 'system') setTheme('light');
    else if (settings.theme === 'light') setTheme('dark');
    else setTheme('system');
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-neutral-900/95 backdrop-blur-md border-b border-neutral-200 dark:border-neutral-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between gap-3">
        {/* Left: Back affordance or Brand Wordmark */}
        <div className="flex items-center gap-3 min-w-0">
          {activeSubjectId && currentTab === 'classes' ? (
            <button
              onClick={() => setActiveSubjectId(null)}
              className="min-h-[44px] min-w-[44px] -ml-2 flex items-center justify-center rounded-lg text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
              aria-label="Back to Classes list"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          ) : null}

          <div className="flex items-baseline gap-2 truncate">
            {activeSubjectId && currentTab === 'classes' && activeSubject ? (
              <div className="flex items-baseline gap-2 truncate">
                <span className="font-semibold text-sm tracking-tight text-neutral-900 dark:text-neutral-100">
                  {activeSubject.code}
                </span>
                <span className="text-xs text-neutral-500 dark:text-neutral-400 truncate hidden sm:inline">
                  {activeSubject.name}
                </span>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <span className="text-base font-bold tracking-tight text-neutral-900 dark:text-white">
                  ClassApp
                </span>
                {!isOnline && (
                  <span className="flex items-center gap-1 text-[10px] font-mono font-medium text-neutral-500 border border-neutral-300 dark:border-neutral-700 px-1.5 py-0.5 rounded">
                    <WifiOff className="w-2.5 h-2.5" />
                    Offline
                  </span>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right Zone: PWA Install + Role Selector + Theme + Profile */}
        <div className="flex items-center gap-2 shrink-0">
          {/* In-App PWA Install Action */}
          <PWAInstallButton />

          {/* Role Selector (Exact Phase 6 Role Scope) */}
          <div className="relative">
            <select
              value={userRole}
              onChange={(e) => setUserRole(e.target.value as UserRole)}
              className="text-xs font-medium bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border border-neutral-200 dark:border-neutral-700 rounded-md px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-neutral-400 cursor-pointer"
              aria-label="Switch User Role"
              title="Test permissions across Student, Class Prefect, Admin, and Platform Owner"
            >
              <option value="student">Student</option>
              <option value="class_manager">Class Prefect (CS 204)</option>
              <option value="class_admin">Class Admin</option>
              <option value="platform_owner">Platform Owner</option>
            </select>
          </div>

          {/* Theme Quick Switcher */}
          <button
            onClick={cycleTheme}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-md text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            aria-label={`Toggle theme (currently ${settings.theme})`}
            title={`Theme: ${settings.theme}`}
          >
            {settings.theme === 'light' ? (
              <Sun className="w-4 h-4" />
            ) : settings.theme === 'dark' ? (
              <Moon className="w-4 h-4" />
            ) : (
              <Monitor className="w-4 h-4" />
            )}
          </button>

          {/* Profile Trigger Button */}
          <button
            onClick={() => setIsProfileOpen(true)}
            className="min-h-[44px] flex items-center gap-2 pl-2 pr-2.5 py-1 rounded-md hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors group"
            aria-label="Open profile and settings"
          >
            <div className="w-7 h-7 rounded-full bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 flex items-center justify-center text-xs font-semibold">
              {userProfile.avatarInitials}
            </div>
            <span className="text-xs font-medium text-neutral-800 dark:text-neutral-200 hidden sm:inline">
              {userProfile.name.split(' ')[0]}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
