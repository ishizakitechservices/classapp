import React from 'react';
import { useApp } from '../context/AppContext';
import { X, Sparkles, CheckCircle2, Download, BookOpen, HardDrive, Share2 } from 'lucide-react';

export const DocumentReaderModal: React.FC = () => {
  const {
    activeReaderFileId,
    setActiveReaderFileId,
    vaultFiles,
    toggleOffline,
    setCurrentTab,
    setActiveQuizOpen,
  } = useApp();

  if (!activeReaderFileId) return null;

  const file = vaultFiles.find((f) => f.id === activeReaderFileId);
  if (!file) return null;

  const handleStudyWithAI = () => {
    setActiveReaderFileId(null);
    setCurrentTab('adom-ai');
    setActiveQuizOpen(true);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5"
      role="dialog"
      aria-modal="true"
      aria-labelledby="doc-reader-title"
    >
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl max-w-3xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden transition-colors">
        {/* Header Bar */}
        <div className="p-4 border-b border-neutral-200 dark:border-neutral-800 flex items-center justify-between gap-3 shrink-0 bg-neutral-50/50 dark:bg-neutral-900/50">
          <div className="min-w-0 flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900 flex items-center justify-center shrink-0">
              <BookOpen className="w-4 h-4" />
            </div>
            <div className="truncate">
              <h2
                id="doc-reader-title"
                className="text-sm font-bold text-neutral-900 dark:text-white truncate"
              >
                {file.name}
              </h2>
              <div className="text-[11px] text-neutral-500 dark:text-neutral-400 flex items-center gap-1.5 font-mono">
                <span>{file.subjectCode}</span>
                <span aria-hidden="true">·</span>
                <span>{file.fileSize}</span>
                <span aria-hidden="true">·</span>
                <span className="uppercase">{file.fileFormat}</span>
                {file.isOffline && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span className="text-neutral-900 dark:text-white font-medium">Cached Offline</span>
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => toggleOffline(file.id)}
              className={`min-h-[38px] px-3 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                file.isOffline
                  ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900'
                  : 'border border-neutral-300 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800'
              }`}
              title={file.isOffline ? 'File saved to IndexedDB offline cache' : 'Save file for offline study'}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{file.isOffline ? 'Offline Ready' : 'Save Offline'}</span>
            </button>

            <button
              onClick={() => setActiveReaderFileId(null)}
              className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-lg text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
              aria-label="Close document reader"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Document Content Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-7 space-y-6 text-neutral-800 dark:text-neutral-200">
          {/* Key Syllabus Concepts banner */}
          <div className="p-3 bg-neutral-100/70 dark:bg-neutral-800/50 rounded-xl border border-neutral-200/80 dark:border-neutral-700/60 text-xs">
            <span className="font-bold text-[11px] uppercase tracking-wider text-neutral-500 block mb-1.5">
              Course Invariants & Concepts
            </span>
            <div className="flex flex-wrap gap-1.5">
              {file.keyConcepts.map((concept, i) => (
                <span
                  key={i}
                  className="px-2 py-0.5 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded text-neutral-800 dark:text-neutral-200 font-medium"
                >
                  {concept}
                </span>
              ))}
            </div>
          </div>

          {/* Render Document Text */}
          <div className="prose prose-sm dark:prose-invert max-w-none text-xs sm:text-sm leading-relaxed whitespace-pre-line font-sans">
            {file.content || file.description}
          </div>
        </div>

        {/* Bottom Action Footer */}
        <div className="p-4 border-t border-neutral-200 dark:border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-3 bg-neutral-50/50 dark:bg-neutral-900/50 shrink-0">
          <div className="text-[11px] text-neutral-500 dark:text-neutral-400">
            {file.isOffline ? 'Available offline via ClassApp IndexedDB storage' : 'Tap "Save Offline" to access without internet'}
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handleStudyWithAI}
              className="flex-1 sm:flex-initial min-h-[40px] px-4 py-2 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 rounded-lg text-xs font-semibold hover:bg-neutral-800 dark:hover:bg-neutral-100 transition-colors flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>Practice Quiz on this File</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
