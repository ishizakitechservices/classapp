import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  TabType,
  UserRole,
  ThemeMode,
  UserProfile,
  Subject,
  VaultFile,
  Notice,
  ChatMessage,
  AppSettings,
  ClassActivity,
  QuizAttempt,
  ConnectedService,
  canManageClass,
  canPublishSchoolNotices,
} from '../types';
import {
  PROFILES,
  INITIAL_SUBJECTS,
  INITIAL_VAULT_FILES,
  INITIAL_NOTICES,
  SAMPLE_CHAT_HISTORY,
  INITIAL_CONNECTED_SERVICES,
} from '../data/mockData';
import {
  STORES,
  dbGetAll,
  dbPut,
  dbPutMany,
  dbDelete,
  dbClear,
  getStorageQuotaEstimate,
} from '../services/db';

interface AppContextType {
  // Navigation
  currentTab: TabType;
  setCurrentTab: (tab: TabType) => void;
  activeSubjectId: string | null;
  setActiveSubjectId: (id: string | null) => void;
  activeFileId: string | null;
  setActiveFileId: (id: string | null) => void;
  activeReaderFileId: string | null;
  setActiveReaderFileId: (id: string | null) => void;
  activeNoticeId: string | null;
  setActiveNoticeId: (id: string | null) => void;
  isProfileOpen: boolean;
  setIsProfileOpen: (open: boolean) => void;
  activeQuizOpen: boolean;
  setActiveQuizOpen: (open: boolean) => void;
  activeFlashcardsOpen: boolean;
  setActiveFlashcardsOpen: (open: boolean) => void;
  activeRevisionTopic: string | null;
  setActiveRevisionTopic: (topic: string | null) => void;

  // Profile & Role
  userProfile: UserProfile;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  canManageCurrentClass: (classId: string) => boolean;
  canPublishNotices: boolean;

  // Settings & Theme
  settings: AppSettings;
  updateSettings: (partial: Partial<AppSettings>) => void;
  setTheme: (theme: ThemeMode) => void;

  // Data & Mutators
  subjects: Subject[];
  addSubjectActivity: (subjectId: string, activity: Omit<ClassActivity, 'id' | 'date'>) => Promise<void>;
  vaultFiles: VaultFile[];
  toggleOffline: (fileId: string) => Promise<void>;
  clearOfflineStorage: () => Promise<void>;
  totalOfflineStorageMB: number;

  notices: Notice[];
  toggleNoticeRead: (noticeId: string) => Promise<void>;
  toggleNoticePin: (noticeId: string) => Promise<void>;
  addNotice: (notice: Omit<Notice, 'id' | 'timeAgo'>) => Promise<void>;
  unreadNoticesCount: number;

  // Adom AI Chat & Quizzes
  chatMessages: ChatMessage[];
  sendMessage: (text: string, contextSubject?: string) => Promise<void>;
  clearChat: () => Promise<void>;
  quizAttempts: QuizAttempt[];
  recordQuizAttempt: (attempt: Omit<QuizAttempt, 'id' | 'timestamp' | 'dateFormatted'>) => Promise<void>;

  // Connected Services (Google Classroom / Drive readiness)
  connectedServices: ConnectedService[];
  toggleConnectedService: (serviceId: 'google_classroom' | 'google_drive') => Promise<void>;

  // Storage & Network Health
  isOnline: boolean;
  storageQuota: { usageMB: number; quotaMB: number; percentageUsed: number };
  refreshStorageStats: () => Promise<void>;
  resetToSampleData: () => Promise<void>;
  isDbReady: boolean;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentTab, setCurrentTabState] = useState<TabType>('home');
  const [activeSubjectId, setActiveSubjectId] = useState<string | null>(null);
  const [activeFileId, setActiveFileId] = useState<string | null>(null);
  const [activeReaderFileId, setActiveReaderFileId] = useState<string | null>(null);
  const [activeNoticeId, setActiveNoticeId] = useState<string | null>(null);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [activeQuizOpen, setActiveQuizOpen] = useState(false);
  const [activeFlashcardsOpen, setActiveFlashcardsOpen] = useState(false);
  const [activeRevisionTopic, setActiveRevisionTopic] = useState<string | null>(null);

  // Network status
  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Role state
  const [userRole, setUserRoleState] = useState<UserRole>(() => {
    return (localStorage.getItem('classapp_role') as UserRole) || 'student';
  });
  const userProfile = PROFILES[userRole] || PROFILES.student;

  // Settings & Theme
  const [settings, setSettings] = useState<AppSettings>(() => {
    const savedTheme = (localStorage.getItem('classapp_theme') as ThemeMode) || 'system';
    return {
      theme: savedTheme,
      fontSize: 'default',
      reducedMotion: false,
      highContrast: false,
      offlineCacheEnabled: true,
      pushNotifications: true,
      quietHours: false,
    };
  });

  // Storage quota
  const [storageQuota, setStorageQuota] = useState({
    usageMB: 0,
    quotaMB: 0,
    percentageUsed: 0,
  });

  // State collections
  const [subjects, setSubjects] = useState<Subject[]>(INITIAL_SUBJECTS);
  const [vaultFiles, setVaultFiles] = useState<VaultFile[]>(INITIAL_VAULT_FILES);
  const [notices, setNotices] = useState<Notice[]>(INITIAL_NOTICES);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(SAMPLE_CHAT_HISTORY);
  const [quizAttempts, setQuizAttempts] = useState<QuizAttempt[]>([]);
  const [connectedServices, setConnectedServices] = useState<ConnectedService[]>(INITIAL_CONNECTED_SERVICES);
  const [isDbReady, setIsDbReady] = useState(false);

  const refreshStorageStats = useCallback(async () => {
    const est = await getStorageQuotaEstimate();
    setStorageQuota({
      usageMB: est.usageMB,
      quotaMB: est.quotaMB,
      percentageUsed: est.percentageUsed,
    });
  }, []);

  // Initialize from IndexedDB with safe seeding
  useEffect(() => {
    let isMounted = true;

    async function loadFromDB() {
      try {
        const [
          savedSubjects,
          savedFiles,
          savedNotices,
          savedMessages,
          savedAttempts,
          savedServices,
        ] = await Promise.all([
          dbGetAll<Subject>(STORES.SUBJECTS),
          dbGetAll<VaultFile>(STORES.VAULT_FILES),
          dbGetAll<Notice>(STORES.NOTICES),
          dbGetAll<ChatMessage>(STORES.CHAT_MESSAGES),
          dbGetAll<QuizAttempt>(STORES.QUIZ_ATTEMPTS),
          dbGetAll<ConnectedService>(STORES.CONNECTED_SERVICES),
        ]);

        if (!isMounted) return;

        // Populate or seed subjects
        if (savedSubjects.length > 0) {
          setSubjects(savedSubjects);
        } else {
          await dbPutMany(STORES.SUBJECTS, INITIAL_SUBJECTS);
          setSubjects(INITIAL_SUBJECTS);
        }

        // Populate or seed vault files
        if (savedFiles.length > 0) {
          setVaultFiles(savedFiles);
        } else {
          await dbPutMany(STORES.VAULT_FILES, INITIAL_VAULT_FILES);
          setVaultFiles(INITIAL_VAULT_FILES);
        }

        // Populate or seed notices
        if (savedNotices.length > 0) {
          setNotices(savedNotices);
        } else {
          await dbPutMany(STORES.NOTICES, INITIAL_NOTICES);
          setNotices(INITIAL_NOTICES);
        }

        // Populate or seed messages
        if (savedMessages.length > 0) {
          setChatMessages(savedMessages);
        } else {
          await dbPutMany(STORES.CHAT_MESSAGES, SAMPLE_CHAT_HISTORY);
          setChatMessages(SAMPLE_CHAT_HISTORY);
        }

        // Populate attempts
        if (savedAttempts.length > 0) {
          setQuizAttempts(savedAttempts.sort((a, b) => b.timestamp.localeCompare(a.timestamp)));
        }

        // Populate services
        if (savedServices.length > 0) {
          setConnectedServices(savedServices);
        } else {
          await dbPutMany(STORES.CONNECTED_SERVICES, INITIAL_CONNECTED_SERVICES);
          setConnectedServices(INITIAL_CONNECTED_SERVICES);
        }

        setIsDbReady(true);
        refreshStorageStats();
      } catch (err) {
        console.warn('Could not initialize from IndexedDB, falling back to memory state:', err);
        setIsDbReady(true);
      }
    }

    loadFromDB();

    return () => {
      isMounted = false;
    };
  }, [refreshStorageStats]);

  // Handle Tab Switch
  const setCurrentTab = (tab: TabType) => {
    setCurrentTabState(tab);
    setActiveFileId(null);
    setActiveReaderFileId(null);
    setActiveNoticeId(null);
  };

  // Sync theme and accessibility options to DOM
  useEffect(() => {
    const root = document.documentElement;
    const isDark =
      settings.theme === 'dark' ||
      (settings.theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);

    if (isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }

    if (settings.highContrast) {
      root.classList.add('contrast-more');
    } else {
      root.classList.remove('contrast-more');
    }

    if (settings.fontSize === 'small') {
      root.style.fontSize = '14px';
    } else if (settings.fontSize === 'large') {
      root.style.fontSize = '17px';
    } else {
      root.style.fontSize = '16px';
    }

    localStorage.setItem('classapp_theme', settings.theme);
  }, [settings.theme, settings.highContrast, settings.fontSize]);

  const setTheme = (theme: ThemeMode) => {
    setSettings((prev) => ({ ...prev, theme }));
  };

  const updateSettings = (partial: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...partial }));
  };

  const setUserRole = (role: UserRole) => {
    setUserRoleState(role);
    localStorage.setItem('classapp_role', role);
  };

  // Permission checkers
  const canManageCurrentClass = (classId: string) => {
    return canManageClass(userRole, classId, userProfile.assignedClassIds || []);
  };

  const canPublishNotices = canPublishSchoolNotices(userRole);

  // Storage calculation
  const totalOfflineStorageMB = vaultFiles
    .filter((f) => f.isOffline)
    .reduce((acc, f) => {
      const num = parseFloat(f.fileSize);
      if (f.fileSize.includes('KB')) return acc + num / 1024;
      return acc + (isNaN(num) ? 1 : num);
    }, 0);

  const toggleOffline = async (fileId: string) => {
    const updated = vaultFiles.map((f) =>
      f.id === fileId
        ? {
            ...f,
            isOffline: !f.isOffline,
            lastCachedAt: !f.isOffline ? new Date().toLocaleDateString() : f.lastCachedAt,
            syncStatus: (!f.isOffline ? 'synced' : 'local_only') as VaultFile['syncStatus'],
          }
        : f
    );
    setVaultFiles(updated);

    const changed = updated.find((f) => f.id === fileId);
    if (changed) {
      await dbPut(STORES.VAULT_FILES, changed);
      refreshStorageStats();
    }
  };

  const clearOfflineStorage = async () => {
    const updated = vaultFiles.map((f) => ({ ...f, isOffline: false, syncStatus: 'local_only' as const }));
    setVaultFiles(updated);
    await dbPutMany(STORES.VAULT_FILES, updated);
    refreshStorageStats();
  };

  // Notices operations
  const toggleNoticeRead = async (noticeId: string) => {
    const updated = notices.map((n) => (n.id === noticeId ? { ...n, isUnread: !n.isUnread } : n));
    setNotices(updated);
    const item = updated.find((n) => n.id === noticeId);
    if (item) await dbPut(STORES.NOTICES, item);
  };

  const toggleNoticePin = async (noticeId: string) => {
    const updated = notices.map((n) => (n.id === noticeId ? { ...n, isPinned: !n.isPinned } : n));
    setNotices(updated);
    const item = updated.find((n) => n.id === noticeId);
    if (item) await dbPut(STORES.NOTICES, item);
  };

  const addNotice = async (notice: Omit<Notice, 'id' | 'timeAgo'>) => {
    const newNotice: Notice = {
      ...notice,
      id: `not-${Date.now()}`,
      timeAgo: 'Just now',
    };
    const updated = [newNotice, ...notices];
    setNotices(updated);
    await dbPut(STORES.NOTICES, newNotice);
  };

  const unreadNoticesCount = notices.filter((n) => n.isUnread).length;

  // Class activity
  const addSubjectActivity = async (subjectId: string, activity: Omit<ClassActivity, 'id' | 'date'>) => {
    const newAct: ClassActivity = {
      ...activity,
      id: `act-${Date.now()}`,
      date: 'Just now',
    };
    let updatedSubj: Subject | null = null;
    const updated = subjects.map((subj) => {
      if (subj.id === subjectId) {
        updatedSubj = { ...subj, activities: [newAct, ...subj.activities] };
        return updatedSubj;
      }
      return subj;
    });
    setSubjects(updated);
    if (updatedSubj) {
      await dbPut(STORES.SUBJECTS, updatedSubj);
    }
  };

  // Chat message operations
  const sendMessage = async (text: string, contextSubject?: string) => {
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      sender: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChatMessages((prev) => [...prev, userMsg]);
    await dbPut(STORES.CHAT_MESSAGES, userMsg);

    // Responsive simulated local study engine
    setTimeout(async () => {
      const lower = text.toLowerCase();
      let responseText = '';
      let mode: ChatMessage['mode'] = 'chat';
      let interactiveData: ChatMessage['interactiveData'];

      if (lower.includes('quiz') || lower.includes('test') || lower.includes('practice')) {
        responseText = `Generated a targeted knowledge check on **${contextSubject || 'Algorithms & Discrete Math'}**. Review your understanding with immediate step-by-step explanations.`;
        mode = 'quiz';
        interactiveData = {
          quizTitle: `${contextSubject || 'Algorithms & Mathematics'} Quick Check`,
        };
      } else if (lower.includes('flashcard') || lower.includes('deck') || lower.includes('cards')) {
        responseText = `Created a focused revision deck. Tap below to launch your study session with spaced recall tracking.`;
        mode = 'flashcards';
      } else if (lower.includes('summar') || lower.includes('note') || lower.includes('outline')) {
        responseText = `Here is a consolidated revision note summary:\n\n• **Core Principle**: Formulate problems in terms of explicit boundary conditions and invariant states.\n• **Algorithmic Cost**: Minimize amortized operations by indexing spatial structures.\n• **Exam Tip**: In exam proofs, state edge condition assumptions clearly before expanding steps.`;
        mode = 'notes';
        interactiveData = {
          summaryBullets: [
            'Formulate problems in terms of explicit boundary conditions.',
            'Maintain monotonic properties during iterative refinement.',
            'Check worst-case bounds against pathological input distributions.',
          ],
        };
      } else if (lower.includes('explain') || lower.includes('how') || lower.includes('what is')) {
        responseText = `**Conceptual Breakdown**:\n\n1. **High-Level Definition**: This mechanism optimizes lookup operations by preserving topological symmetry across nodes.\n2. **Under the Hood**: Every traversal guarantees bounded depth ($O(\\log n)$ or $O(V + E)$ depending on edge representation).\n3. **Practical Application**: Used in routing tables, cache eviction policies, and network scheduling.`;
        mode = 'explain';
      } else {
        responseText = `I've analyzed your question regarding your coursework. To revise effectively:\n\n• Check the lecture slides in **Vault** for the formal proof.\n• Run a self-test with the interactive **Quiz** mode.\n• Tap the **Flashcards** module below to cement fundamental definitions.`;
      }

      const botMsg: ChatMessage = {
        id: `a-${Date.now()}`,
        sender: 'assistant',
        content: responseText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        mode,
        interactiveData,
      };

      setChatMessages((prev) => [...prev, botMsg]);
      await dbPut(STORES.CHAT_MESSAGES, botMsg);
    }, 400);
  };

  const clearChat = async () => {
    setChatMessages([]);
    await dbClear(STORES.CHAT_MESSAGES);
  };

  // Quiz attempt tracking
  const recordQuizAttempt = async (attempt: Omit<QuizAttempt, 'id' | 'timestamp' | 'dateFormatted'>) => {
    const record: QuizAttempt = {
      ...attempt,
      id: `qa-${Date.now()}`,
      timestamp: new Date().toISOString(),
      dateFormatted: new Date().toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
    };
    const updated = [record, ...quizAttempts];
    setQuizAttempts(updated);
    await dbPut(STORES.QUIZ_ATTEMPTS, record);
  };

  // Connected Services toggle (Google Classroom / Google Drive)
  const toggleConnectedService = async (serviceId: 'google_classroom' | 'google_drive') => {
    const updated = connectedServices.map((svc) => {
      if (svc.id === serviceId) {
        const nextState = !svc.isConnected;
        return {
          ...svc,
          isConnected: nextState,
          accountEmail: nextState ? userProfile.email : undefined,
          lastSyncedAt: nextState ? 'Just now' : undefined,
        };
      }
      return svc;
    });
    setConnectedServices(updated);
    const changed = updated.find((s) => s.id === serviceId);
    if (changed) await dbPut(STORES.CONNECTED_SERVICES, changed);
  };

  // Reset to initial sample data
  const resetToSampleData = async () => {
    await Promise.all([
      dbClear(STORES.SUBJECTS),
      dbClear(STORES.VAULT_FILES),
      dbClear(STORES.NOTICES),
      dbClear(STORES.CHAT_MESSAGES),
      dbClear(STORES.QUIZ_ATTEMPTS),
      dbClear(STORES.CONNECTED_SERVICES),
    ]);
    await Promise.all([
      dbPutMany(STORES.SUBJECTS, INITIAL_SUBJECTS),
      dbPutMany(STORES.VAULT_FILES, INITIAL_VAULT_FILES),
      dbPutMany(STORES.NOTICES, INITIAL_NOTICES),
      dbPutMany(STORES.CHAT_MESSAGES, SAMPLE_CHAT_HISTORY),
      dbPutMany(STORES.CONNECTED_SERVICES, INITIAL_CONNECTED_SERVICES),
    ]);
    setSubjects(INITIAL_SUBJECTS);
    setVaultFiles(INITIAL_VAULT_FILES);
    setNotices(INITIAL_NOTICES);
    setChatMessages(SAMPLE_CHAT_HISTORY);
    setQuizAttempts([]);
    setConnectedServices(INITIAL_CONNECTED_SERVICES);
    refreshStorageStats();
  };

  return (
    <AppContext.Provider
      value={{
        currentTab,
        setCurrentTab,
        activeSubjectId,
        setActiveSubjectId,
        activeFileId,
        setActiveFileId,
        activeReaderFileId,
        setActiveReaderFileId,
        activeNoticeId,
        setActiveNoticeId,
        isProfileOpen,
        setIsProfileOpen,
        activeQuizOpen,
        setActiveQuizOpen,
        activeFlashcardsOpen,
        setActiveFlashcardsOpen,
        activeRevisionTopic,
        setActiveRevisionTopic,
        userProfile,
        userRole,
        setUserRole,
        canManageCurrentClass,
        canPublishNotices,
        settings,
        updateSettings,
        setTheme,
        subjects,
        addSubjectActivity,
        vaultFiles,
        toggleOffline,
        clearOfflineStorage,
        totalOfflineStorageMB,
        notices,
        toggleNoticeRead,
        toggleNoticePin,
        addNotice,
        unreadNoticesCount,
        chatMessages,
        sendMessage,
        clearChat,
        quizAttempts,
        recordQuizAttempt,
        connectedServices,
        toggleConnectedService,
        isOnline,
        storageQuota,
        refreshStorageStats,
        resetToSampleData,
        isDbReady,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
