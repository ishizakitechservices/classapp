# ClassApp

ClassApp is currently a **front-end demonstration prototype** built with React, TypeScript, Vite, and Tailwind CSS. It uses sample data to demonstrate navigation and learning workflows.

## Run locally

Requirements: Node.js 22.12+ (or a Node version supported by the installed Vite release) and npm.

```bash
npm install
npm run lint
npm run build
npm run dev
```

Open the local URL printed by Vite.

## Current limitations

- Adom AI responses are simulated; a real AI provider is not connected.
- Subjects, notices, chat messages, and Vault file entries are in-memory sample data and are not durable user data.
- Vault offline toggles are demonstration indicators, not verified file downloads or offline storage.
- There is no production authentication, server-side role enforcement, Google Classroom/Drive integration, or service-worker offline support yet.
- Do not use this prototype for private student records or real credentials.

Implement persistence, authentication, real AI, Google integrations, and offline caching as separate tested phases.
