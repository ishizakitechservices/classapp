import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  TabType,
  UserRole,
  ThemeMode,
  UserProfile,
  Subject,
  VaultFile,
  Notice,
  ChatMessage,
  AppSettings,
  ClassActivity,
} from '../types';
import {
  PROFILES,
  INITIAL_SUBJECTS,
  INITIAL_VAULT_FILES,
  INITIAL_NOTICES,
  SAMPLE_CHAT_HISTORY,
} from '../data/mockData';

interface AppContextType {
  // Navigation
  currentTab: TabType;
  setCurrentTab: (tab: TabType) => void;
  activeSubjectId: string | null;
  setActiveSubjectId: (id: string | null) => void;
  activeFileId: string | null;
  setActiveFileId: (id: string | null) => void;
  activeNoticeId: string | null;
  setActiveNoticeId: (id: string | null) => void;
  isProfileOpen: boolean;
  setIsProfileOpen: (open: boolean) => void;
  activeQuizOpen: boolean;
  setActiveQuizOpen: (open: boolean) => void;
  activeFlashcardsOpen: boolean;
  setActiveFlashcardsOpen: (open: boolean) => void;
  activeRevisionTopic: string | null;
  setActiveRevisionTopic: (topic: string | null) => void;

  // Profile & Role
  userProfile: UserProfile;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;

  // Settings & Theme
  settings: AppSettings;
  updateSettings: (partial: Partial<AppSettings>) => void;
  setTheme: (theme: ThemeMode) => void;

  // Data & Mutators
  subjects: Subject[];
  addSubjectActivity: (subjectId: string, activity: Omit<ClassActivity, 'id' | 'date'>) => void;
  vaultFiles: VaultFile[];
  toggleOffline: (fileId: string) => void;
  clearOfflineStorage: () => void;
  totalOfflineStorageMB: number;

  notices: Notice[];
  toggleNoticeRead: (noticeId: string) => void;
  toggleNoticePin: (noticeId: string) => void;
  unreadNoticesCount: number;

  // Adom AI Chat
  chatMessages: ChatMessage[];
  sendMessage: (text: string, contextSubject?: string) => void;
  clearChat: () => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentTab, setCurrentTabState] = useState<TabType>('home');
  const [activeSubjectId, setActiveSubjectId] = useState<string | null>(null);
  const [activeFileId, setActiveFileId] = useState<string | null>(null);
  const [activeNoticeId, setActiveNoticeId] = useState<string | null>(null);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [activeQuizOpen, setActiveQuizOpen] = useState(false);
  const [activeFlashcardsOpen, setActiveFlashcardsOpen] = useState(false);
  const [activeRevisionTopic, setActiveRevisionTopic] = useState<string | null>(null);

  // Role
  const [userRole, setUserRoleState] = useState<UserRole>('student');
  const userProfile = PROFILES[userRole] || PROFILES.student;

  // Settings & Theme
  const [settings, setSettings] = useState<AppSettings>(() => {
    const savedTheme = (localStorage.getItem('classapp_theme') as ThemeMode) || 'system';
    return {
      theme: savedTheme,
      fontSize: 'default',
      reducedMotion: false,
      highContrast: false,
      offlineCacheEnabled: true,
      pushNotifications: true,
      quietHours: false,
    };
  });

  // State collections
  const [subjects, setSubjects] = useState<Subject[]>(INITIAL_SUBJECTS);
  const [vaultFiles, setVaultFiles] = useState<VaultFile[]>(INITIAL_VAULT_FILES);
  const [notices, setNotices] = useState<Notice[]>(INITIAL_NOTICES);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(SAMPLE_CHAT_HISTORY);

  // Handle Tab Switch (clears child detail state cleanly)
  const setCurrentTab = (tab: TabType) => {
    setCurrentTabState(tab);
    // Don't auto-clear subject if staying in classes, but clear modals
    setActiveFileId(null);
    setActiveNoticeId(null);
  };

  // Sync theme to DOM
  useEffect(() => {
    const root = document.documentElement;
    const isDark =
      settings.theme === 'dark' ||
      (settings.theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);

    if (isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }

    // High contrast support
    if (settings.highContrast) {
      root.classList.add('contrast-more');
    } else {
      root.classList.remove('contrast-more');
    }

    // Font size scaling
    if (settings.fontSize === 'small') {
      root.style.fontSize = '14px';
    } else if (settings.fontSize === 'large') {
      root.style.fontSize = '17px';
    } else {
      root.style.fontSize = '16px';
    }

    localStorage.setItem('classapp_theme', settings.theme);
  }, [settings.theme, settings.highContrast, settings.fontSize]);

  const setTheme = (theme: ThemeMode) => {
    setSettings((prev) => ({ ...prev, theme }));
  };

  const updateSettings = (partial: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...partial }));
  };

  const setUserRole = (role: UserRole) => {
    setUserRoleState(role);
  };

  // Offline storage calculation
  const totalOfflineStorageMB = vaultFiles
    .filter((f) => f.isOffline)
    .reduce((acc, f) => {
      const num = parseFloat(f.fileSize);
      if (f.fileSize.includes('KB')) return acc + num / 1024;
      return acc + (isNaN(num) ? 1 : num);
    }, 0);

  const toggleOffline = (fileId: string) => {
    setVaultFiles((prev) =>
      prev.map((f) => (f.id === fileId ? { ...f, isOffline: !f.isOffline } : f))
    );
  };

  const clearOfflineStorage = () => {
    setVaultFiles((prev) => prev.map((f) => ({ ...f, isOffline: false })));
  };

  // Notices operations
  const toggleNoticeRead = (noticeId: string) => {
    setNotices((prev) =>
      prev.map((n) => (n.id === noticeId ? { ...n, isUnread: !n.isUnread } : n))
    );
  };

  const toggleNoticePin = (noticeId: string) => {
    setNotices((prev) =>
      prev.map((n) => (n.id === noticeId ? { ...n, isPinned: !n.isPinned } : n))
    );
  };

  const unreadNoticesCount = notices.filter((n) => n.isUnread).length;

  // Add Subject Activity (for teacher/class_rep roles)
  const addSubjectActivity = (subjectId: string, activity: Omit<ClassActivity, 'id' | 'date'>) => {
    const newAct: ClassActivity = {
      ...activity,
      id: `act-${Date.now()}`,
      date: 'Just now',
    };
    setSubjects((prev) =>
      prev.map((subj) =>
        subj.id === subjectId
          ? { ...subj, activities: [newAct, ...subj.activities] }
          : subj
      )
    );
  };

  // Chat logic (Demonstration mode with realistic responses)
  const sendMessage = (text: string, contextSubject?: string) => {
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      sender: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChatMessages((prev) => [...prev, userMsg]);

    // Generate responsive simulated answer
    setTimeout(() => {
      const lower = text.toLowerCase();
      let responseText = '';
      let mode: ChatMessage['mode'] = 'chat';
      let interactiveData: ChatMessage['interactiveData'];

      if (lower.includes('quiz') || lower.includes('test') || lower.includes('practice')) {
        responseText = `Generated a targeted knowledge check on **${contextSubject || 'Core Concepts'}**. Review your understanding with immediate step-by-step explanations.`;
        mode = 'quiz';
        interactiveData = {
          quizTitle: `${contextSubject || 'Algorithms & Mathematics'} Quick Check`,
        };
      } else if (lower.includes('flashcard') || lower.includes('deck') || lower.includes('cards')) {
        responseText = `Created a focused revision deck. Tap below to launch your study session with spaced recall tracking.`;
        mode = 'flashcards';
      } else if (lower.includes('summar') || lower.includes('note') || lower.includes('outline')) {
        responseText = `Here is a consolidated revision note summary:\n\n• **Core Principle**: Formulate problems in terms of explicit boundary conditions and invariant states.\n• **Algorithmic Cost**: Minimize amortized operations by indexing spatial structures.\n• **Exam Tip**: In exam proofs, state edge condition assumptions clearly before expanding steps.`;
        mode = 'notes';
        interactiveData = {
          summaryBullets: [
            'Formulate problems in terms of explicit boundary conditions.',
            'Maintain monotonic properties during iterative refinement.',
            'Check worst-case bounds against pathological input distributions.',
          ],
        };
      } else if (lower.includes('explain') || lower.includes('how') || lower.includes('what is')) {
        responseText = `**Conceptual Breakdown**:\n\n1. **High-Level Definition**: This mechanism optimizes lookup operations by preserving topological symmetry across nodes.\n2. **Under the Hood**: Every traversal guarantees bounded depth ($O(\\log n)$ or $O(V + E)$ depending on edge representation).\n3. **Practical Application**: Used in routing tables, cache eviction policies, and network scheduling.`;
        mode = 'explain';
      } else {
        responseText = `I've analyzed your question regarding your coursework. To revise effectively:\n\n• Check the lecture slides in **Vault** for the formal proof.\n• Run a self-test with the interactive **Quiz** mode.\n• Tap the **Flashcards** module below to cement fundamental definitions.`;
      }

      const botMsg: ChatMessage = {
        id: `a-${Date.now()}`,
        sender: 'assistant',
        content: responseText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        mode,
        interactiveData,
      };

      setChatMessages((prev) => [...prev, botMsg]);
    }, 450);
  };

  const clearChat = () => {
    setChatMessages([]);
  };

  return (
    <AppContext.Provider
      value={{
        currentTab,
        setCurrentTab,
        activeSubjectId,
        setActiveSubjectId,
        activeFileId,
        setActiveFileId,
        activeNoticeId,
        setActiveNoticeId,
        isProfileOpen,
        setIsProfileOpen,
        activeQuizOpen,
        setActiveQuizOpen,
        activeFlashcardsOpen,
        setActiveFlashcardsOpen,
        activeRevisionTopic,
        setActiveRevisionTopic,
        userProfile,
        userRole,
        setUserRole,
        settings,
        updateSettings,
        setTheme,
        subjects,
        addSubjectActivity,
        vaultFiles,
        toggleOffline,
        clearOfflineStorage,
        totalOfflineStorageMB,
        notices,
        toggleNoticeRead,
        toggleNoticePin,
        unreadNoticesCount,
        chatMessages,
        sendMessage,
        clearChat,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
