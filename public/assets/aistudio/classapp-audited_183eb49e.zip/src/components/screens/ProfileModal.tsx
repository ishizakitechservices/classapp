import React from 'react';
import { useApp } from '../../context/AppContext';
import { UserRole, ThemeMode } from '../../types';
import {
  X,
  User,
  Moon,
  Sun,
  Monitor,
  HardDrive,
  Eye,
  Bell,
  ShieldCheck,
  Check,
} from 'lucide-react';

export const ProfileModal: React.FC = () => {
  const {
    isProfileOpen,
    setIsProfileOpen,
    userProfile,
    userRole,
    setUserRole,
    settings,
    updateSettings,
    setTheme,
    totalOfflineStorageMB,
    clearOfflineStorage,
  } = useApp();

  if (!isProfileOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl max-w-md w-full max-h-[90vh] overflow-y-auto p-6 space-y-6 shadow-2xl transition-colors">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-neutral-100 dark:border-neutral-800 pb-3">
          <h2 className="text-base font-bold text-neutral-900 dark:text-white">
            Account & Preferences
          </h2>
          <button
            onClick={() => setIsProfileOpen(false)}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center text-neutral-400 hover:text-neutral-900 dark:hover:text-white"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Account Details & Role Switcher */}
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 flex items-center justify-center text-sm font-bold shrink-0">
              {userProfile.avatarInitials}
            </div>
            <div className="min-w-0">
              <h3 className="text-sm font-bold text-neutral-900 dark:text-white truncate">
                {userProfile.name}
              </h3>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 truncate">
                {userProfile.email}
              </p>
              <p className="text-[11px] font-mono text-neutral-400">
                {userProfile.idNumber}
              </p>
            </div>
          </div>

          {/* Role Switcher (Allows testing student vs teacher/rep access) */}
          <div className="pt-2">
            <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-500 mb-1.5">
              Current Simulation Role
            </label>
            <div className="grid grid-cols-3 gap-2 text-xs">
              {(['student', 'class_rep', 'teacher'] as UserRole[]).map((role) => (
                <button
                  key={role}
                  onClick={() => setUserRole(role)}
                  className={`min-h-[44px] px-2 py-1.5 rounded-lg border text-center transition-colors ${
                    userRole === role
                      ? 'border-neutral-900 dark:border-white bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 font-semibold'
                      : 'border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
                  }`}
                >
                  <span className="capitalize">{role.replace('_', ' ')}</span>
                </button>
              ))}
            </div>
            <p className="text-[11px] text-neutral-400 mt-1">
              Switching to Teacher or Class Rep displays course management actions in Classes.
            </p>
          </div>
        </div>

        {/* Appearance & Themes */}
        <div className="space-y-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
          <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-500">
            Appearance
          </label>
          <div className="grid grid-cols-3 gap-2 text-xs">
            {(['light', 'dark', 'system'] as ThemeMode[]).map((mode) => (
              <button
                key={mode}
                onClick={() => setTheme(mode)}
                className={`min-h-[44px] px-2 py-2 rounded-lg border flex flex-col items-center justify-center gap-1 transition-colors ${
                  settings.theme === mode
                    ? 'border-neutral-900 dark:border-white bg-neutral-100 dark:bg-neutral-800 font-semibold text-neutral-900 dark:text-white'
                    : 'border-neutral-200 dark:border-neutral-800 text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
                }`}
              >
                {mode === 'light' && <Sun className="w-4 h-4" />}
                {mode === 'dark' && <Moon className="w-4 h-4" />}
                {mode === 'system' && <Monitor className="w-4 h-4" />}
                <span className="capitalize text-[11px]">{mode}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Accessibility */}
        <div className="space-y-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
          <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-500">
            Accessibility & Text
          </label>

          {/* Font Scale */}
          <div className="flex items-center justify-between text-xs">
            <span className="text-neutral-700 dark:text-neutral-300">Reading Size</span>
            <div className="flex gap-1">
              {(['small', 'default', 'large'] as const).map((sz) => (
                <button
                  key={sz}
                  onClick={() => updateSettings({ fontSize: sz })}
                  className={`px-2.5 py-1 text-xs rounded border capitalize transition-colors ${
                    settings.fontSize === sz
                      ? 'border-neutral-900 dark:border-white bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 font-bold'
                      : 'border-neutral-200 dark:border-neutral-800 text-neutral-500'
                  }`}
                >
                  {sz}
                </button>
              ))}
            </div>
          </div>

          {/* Reduced Motion Toggle */}
          <div className="flex items-center justify-between text-xs pt-1">
            <span className="text-neutral-700 dark:text-neutral-300">Reduced Motion</span>
            <button
              onClick={() => updateSettings({ reducedMotion: !settings.reducedMotion })}
              className={`min-h-[32px] px-3 rounded-full text-[11px] font-medium border transition-colors ${
                settings.reducedMotion
                  ? 'border-neutral-900 dark:border-white bg-neutral-900 text-white dark:bg-white dark:text-neutral-900'
                  : 'border-neutral-200 dark:border-neutral-800 text-neutral-500'
              }`}
            >
              {settings.reducedMotion ? 'Enabled' : 'Off'}
            </button>
          </div>

          {/* High Contrast Toggle */}
          <div className="flex items-center justify-between text-xs pt-1">
            <span className="text-neutral-700 dark:text-neutral-300">High Contrast</span>
            <button
              onClick={() => updateSettings({ highContrast: !settings.highContrast })}
              className={`min-h-[32px] px-3 rounded-full text-[11px] font-medium border transition-colors ${
                settings.highContrast
                  ? 'border-neutral-900 dark:border-white bg-neutral-900 text-white dark:bg-white dark:text-neutral-900'
                  : 'border-neutral-200 dark:border-neutral-800 text-neutral-500'
              }`}
            >
              {settings.highContrast ? 'Enabled' : 'Off'}
            </button>
          </div>
        </div>

        {/* Offline Storage & Cache */}
        <div className="space-y-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
          <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-500">
            Local Offline Storage
          </label>
          <div className="p-3 bg-neutral-50 dark:bg-neutral-800/50 rounded-xl flex items-center justify-between text-xs">
            <div>
              <span className="text-neutral-500 dark:text-neutral-400 block text-[11px]">
                Cached Lecture Files
              </span>
              <span className="font-mono font-bold text-neutral-900 dark:text-white">
                {totalOfflineStorageMB.toFixed(1)} MB allocated
              </span>
            </div>
            <button
              onClick={clearOfflineStorage}
              disabled={totalOfflineStorageMB === 0}
              className="px-3 py-1.5 border border-neutral-300 dark:border-neutral-700 rounded-lg text-xs font-medium text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 disabled:opacity-40 transition-colors"
            >
              Clear Cache
            </button>
          </div>
        </div>

        {/* App Info Footer */}
        <div className="pt-2 text-center text-[11px] text-neutral-400">
          ClassApp Foundation · Spring 2026 Build
        </div>
      </div>
    </div>
  );
};
