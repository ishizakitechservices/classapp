import React from 'react';
import { useApp } from '../../context/AppContext';
import { BookOpen, FolderArchive, Sparkles, Bell, ArrowRight, Clock, MapPin, CheckCircle2, CloudDownload } from 'lucide-react';

export const HomeScreen: React.FC = () => {
  const {
    userProfile,
    subjects,
    vaultFiles,
    notices,
    setCurrentTab,
    setActiveSubjectId,
    setActiveFileId,
    setActiveNoticeId,
    setActiveQuizOpen,
  } = useApp();

  const currentSubject = subjects[0]; // e.g. CS 204
  const recentFiles = vaultFiles.slice(0, 3);
  const topNotices = notices.slice(0, 2);

  return (
    <div className="space-y-6 pb-20 md:pb-8">
      {/* Welcome & Semester Context */}
      <section className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-5 transition-colors">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="text-xs text-neutral-500 dark:text-neutral-400 mb-1">
              Welcome back, {userProfile.name.split(' ')[0]}
            </div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-neutral-900 dark:text-white">
              {userProfile.program}
            </h1>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
              {userProfile.semester} · {userProfile.idNumber}
            </p>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            <button
              onClick={() => {
                setActiveSubjectId(currentSubject.id);
                setCurrentTab('classes');
              }}
              className="min-h-[44px] px-4 py-2 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 rounded-lg text-xs font-semibold hover:bg-neutral-800 dark:hover:bg-neutral-100 transition-colors flex items-center gap-2 shadow-sm"
            >
              <span>Continue Learning</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Continue Learning card details */}
        {currentSubject && (
          <div className="mt-4 pt-4 border-t border-neutral-100 dark:border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 text-neutral-600 dark:text-neutral-300">
              <span className="font-semibold text-neutral-900 dark:text-white">
                Next: {currentSubject.code}
              </span>
              <span aria-hidden="true">·</span>
              <span>{currentSubject.name}</span>
            </div>
            <div className="flex items-center gap-4 text-neutral-500 dark:text-neutral-400">
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {currentSubject.nextSession}
              </span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5" />
                {currentSubject.room}
              </span>
            </div>
          </div>
        )}
      </section>

      {/* Quick Launchpad Strip */}
      <section className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <button
          onClick={() => setCurrentTab('classes')}
          className="min-h-[44px] p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl text-left hover:border-neutral-400 dark:hover:border-neutral-700 transition-colors group"
        >
          <BookOpen className="w-5 h-5 text-neutral-900 dark:text-white mb-2" />
          <div className="text-sm font-semibold text-neutral-900 dark:text-white">Classes</div>
          <div className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
            {subjects.length} active courses
          </div>
        </button>

        <button
          onClick={() => setCurrentTab('vault')}
          className="min-h-[44px] p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl text-left hover:border-neutral-400 dark:hover:border-neutral-700 transition-colors group"
        >
          <FolderArchive className="w-5 h-5 text-neutral-900 dark:text-white mb-2" />
          <div className="text-sm font-semibold text-neutral-900 dark:text-white">Vault</div>
          <div className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
            {vaultFiles.length} files saved
          </div>
        </button>

        <button
          onClick={() => {
            setCurrentTab('adom-ai');
            setActiveQuizOpen(true);
          }}
          className="min-h-[44px] p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl text-left hover:border-neutral-400 dark:hover:border-neutral-700 transition-colors group"
        >
          <Sparkles className="w-5 h-5 text-neutral-900 dark:text-white mb-2" />
          <div className="text-sm font-semibold text-neutral-900 dark:text-white">Adom AI</div>
          <div className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
            Interactive quizzes
          </div>
        </button>

        <button
          onClick={() => setCurrentTab('notices')}
          className="min-h-[44px] p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl text-left hover:border-neutral-400 dark:hover:border-neutral-700 transition-colors group"
        >
          <Bell className="w-5 h-5 text-neutral-900 dark:text-white mb-2" />
          <div className="text-sm font-semibold text-neutral-900 dark:text-white">Notices</div>
          <div className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
            {notices.filter((n) => n.isUnread).length} unread updates
          </div>
        </button>
      </section>

      {/* 2-Column Split: Recent Resources & Relevant Notices */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Resources */}
        <section className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold tracking-tight text-neutral-900 dark:text-white">
              Recent Vault Resources
            </h2>
            <button
              onClick={() => setCurrentTab('vault')}
              className="text-xs text-neutral-500 hover:text-neutral-900 dark:hover:text-white transition-colors"
            >
              View all
            </button>
          </div>

          <div className="space-y-2">
            {recentFiles.map((file) => (
              <div
                key={file.id}
                onClick={() => setActiveFileId(file.id)}
                className="min-h-[44px] p-3 rounded-lg border border-neutral-100 dark:border-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-800/50 cursor-pointer transition-colors flex items-center justify-between gap-3"
              >
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-semibold text-neutral-900 dark:text-white truncate">
                    {file.name}
                  </div>
                  <div className="text-[11px] text-neutral-500 dark:text-neutral-400 flex items-center gap-1.5 mt-0.5">
                    <span>{file.subjectCode}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono">{file.fileSize}</span>
                    <span aria-hidden="true">·</span>
                    <span>{file.updatedAt}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {file.isOffline && (
                    <span className="flex items-center gap-1 text-[10px] text-neutral-600 dark:text-neutral-300 font-medium">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Offline
                    </span>
                  )}
                  <span className="text-[10px] font-mono uppercase font-semibold text-neutral-600 dark:text-neutral-400 px-1.5 py-0.5 bg-neutral-100 dark:bg-neutral-800 rounded">
                    {file.fileFormat}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Relevant Notices */}
        <section className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold tracking-tight text-neutral-900 dark:text-white">
              Announcements & Notices
            </h2>
            <button
              onClick={() => setCurrentTab('notices')}
              className="text-xs text-neutral-500 hover:text-neutral-900 dark:hover:text-white transition-colors"
            >
              View all
            </button>
          </div>

          <div className="space-y-2">
            {topNotices.map((notice) => (
              <div
                key={notice.id}
                onClick={() => setActiveNoticeId(notice.id)}
                className="min-h-[44px] p-3 rounded-lg border border-neutral-100 dark:border-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-800/50 cursor-pointer transition-colors"
              >
                <div className="flex items-start justify-between gap-2">
                  <h3 className="text-xs font-semibold text-neutral-900 dark:text-white line-clamp-1">
                    {notice.title}
                  </h3>
                  {notice.isUnread && (
                    <span className="w-2 h-2 rounded-full bg-neutral-900 dark:bg-neutral-100 shrink-0 mt-1" />
                  )}
                </div>
                <div className="text-[11px] text-neutral-500 dark:text-neutral-400 flex items-center gap-1.5 mt-1">
                  <span>{notice.department}</span>
                  <span aria-hidden="true">·</span>
                  <span>{notice.timeAgo}</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};
