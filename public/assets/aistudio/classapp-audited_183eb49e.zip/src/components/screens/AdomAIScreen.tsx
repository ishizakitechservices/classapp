import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { SAMPLE_QUIZ_QUESTIONS, SAMPLE_FLASHCARDS } from '../../data/mockData';
import {
  Sparkles,
  Send,
  HelpCircle,
  Layers,
  FileText,
  RotateCw,
  CheckCircle2,
  XCircle,
  Info,
  ChevronRight,
  ChevronLeft,
} from 'lucide-react';

export const AdomAIScreen: React.FC = () => {
  const {
    chatMessages,
    sendMessage,
    activeQuizOpen,
    setActiveQuizOpen,
    activeFlashcardsOpen,
    setActiveFlashcardsOpen,
  } = useApp();

  const [inputVal, setInputVal] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Quiz State
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState(0);
  const [isQuizComplete, setIsQuizComplete] = useState(false);

  // Flashcards State
  const [flashcardIndex, setFlashcardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [knownCards, setKnownCards] = useState<string[]>([]);

  // Revision Note Drawer/Modal
  const [activeNoteTopic, setActiveNoteTopic] = useState<string | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim()) return;
    sendMessage(inputVal);
    setInputVal('');
  };

  const startQuiz = () => {
    setCurrentQuestionIndex(0);
    setSelectedAnswer(null);
    setIsAnswerSubmitted(false);
    setQuizScore(0);
    setIsQuizComplete(false);
    setActiveQuizOpen(true);
  };

  const handleAnswerSubmit = () => {
    if (selectedAnswer === null) return;
    setIsAnswerSubmitted(true);
    if (selectedAnswer === SAMPLE_QUIZ_QUESTIONS[currentQuestionIndex].correctAnswerIndex) {
      setQuizScore((prev) => prev + 1);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < SAMPLE_QUIZ_QUESTIONS.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
      setSelectedAnswer(null);
      setIsAnswerSubmitted(false);
    } else {
      setIsQuizComplete(true);
    }
  };

  const startFlashcards = () => {
    setFlashcardIndex(0);
    setIsFlipped(false);
    setActiveFlashcardsOpen(true);
  };

  return (
    <div className="space-y-4 pb-20 md:pb-8 flex flex-col h-[calc(100dvh-120px)] md:h-[calc(100vh-100px)]">
      {/* Header & Transparency Notice */}
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-4 shrink-0 transition-colors">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-neutral-900 dark:text-white" />
              <h1 className="text-base font-bold text-neutral-900 dark:text-white">
                Adom AI Study Assistant
              </h1>
            </div>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
              Personalized concept explanations, quick self-quizzes, and flashcards.
            </p>
          </div>

          {/* Explicit Demonstration Label (Prompt compliance) */}
          <div className="flex items-center gap-1.5 text-[11px] font-mono text-neutral-600 dark:text-neutral-400 bg-neutral-100 dark:bg-neutral-800 px-2.5 py-1 rounded-md self-start sm:self-auto">
            <Info className="w-3.5 h-3.5 text-neutral-500" />
            <span>Demonstration Data Mode</span>
          </div>
        </div>

        {/* Quick Study Entry Points */}
        <div className="flex items-center gap-2 overflow-x-auto pt-3 border-t border-neutral-100 dark:border-neutral-800 mt-3 text-xs">
          <button
            onClick={startQuiz}
            className="min-h-[36px] px-3 py-1.5 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800/60 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-800 dark:text-neutral-200 flex items-center gap-1.5 font-medium whitespace-nowrap transition-colors"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Interactive Quiz (3 Qs)</span>
          </button>

          <button
            onClick={startFlashcards}
            className="min-h-[36px] px-3 py-1.5 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800/60 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-800 dark:text-neutral-200 flex items-center gap-1.5 font-medium whitespace-nowrap transition-colors"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Study Flashcard Deck</span>
          </button>

          <button
            onClick={() =>
              setActiveNoteTopic(
                'Graph Traversals & Asymptotic Complexities: BFS explores shallowest frontiers first using a FIFO queue; DFS exhausts deep paths via recursion or a stack.'
              )
            }
            className="min-h-[36px] px-3 py-1.5 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800/60 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-800 dark:text-neutral-200 flex items-center gap-1.5 font-medium whitespace-nowrap transition-colors"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Revision Notes</span>
          </button>
        </div>
      </div>

      {/* Chat Messages Log */}
      <div className="flex-1 overflow-y-auto space-y-3 p-1">
        {chatMessages.map((msg) => {
          const isUser = msg.sender === 'user';
          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[88%] sm:max-w-xl rounded-xl p-4 text-xs leading-relaxed ${
                  isUser
                    ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 font-medium'
                    : 'bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 text-neutral-800 dark:text-neutral-200'
                }`}
              >
                <div className="whitespace-pre-line">{msg.content}</div>

                {/* If message offers an embedded action */}
                {msg.mode === 'quiz' && (
                  <button
                    onClick={startQuiz}
                    className="mt-3 min-h-[36px] px-3 py-1.5 bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900 rounded-md text-xs font-semibold flex items-center gap-1.5 hover:opacity-90 transition-opacity"
                  >
                    <HelpCircle className="w-3.5 h-3.5" />
                    <span>Launch Knowledge Quiz</span>
                  </button>
                )}

                {msg.mode === 'flashcards' && (
                  <button
                    onClick={startFlashcards}
                    className="mt-3 min-h-[36px] px-3 py-1.5 bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900 rounded-md text-xs font-semibold flex items-center gap-1.5 hover:opacity-90 transition-opacity"
                  >
                    <Layers className="w-3.5 h-3.5" />
                    <span>Open Flashcards</span>
                  </button>
                )}
              </div>

              <span className="text-[10px] text-neutral-400 mt-1 px-1 font-mono">
                {msg.timestamp}
              </span>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Bottom Message Input Bar */}
      <form
        onSubmit={handleSend}
        className="shrink-0 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-2 flex items-center gap-2"
      >
        <input
          type="text"
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          placeholder="Ask Adom AI to explain a theorem, generate a quiz, or summarize..."
          className="flex-1 bg-transparent px-3 py-2 text-xs text-neutral-900 dark:text-white placeholder-neutral-400 focus:outline-none"
        />
        <button
          type="submit"
          disabled={!inputVal.trim()}
          className="min-h-[40px] min-w-[40px] px-3 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 rounded-lg flex items-center justify-center disabled:opacity-40 hover:opacity-90 transition-opacity"
          aria-label="Send message"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>

      {/* Interactive Quiz Runner Modal */}
      {activeQuizOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-100 dark:border-neutral-800 pb-3">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-neutral-500">
                  Concept Checkpoint · Question {currentQuestionIndex + 1} of {SAMPLE_QUIZ_QUESTIONS.length}
                </span>
                <h3 className="text-sm font-bold text-neutral-900 dark:text-white">
                  CS 204: Algorithms & Complexity
                </h3>
              </div>
              <button
                onClick={() => setActiveQuizOpen(false)}
                className="text-xs text-neutral-400 hover:text-neutral-900 dark:hover:text-white"
              >
                ✕
              </button>
            </div>

            {!isQuizComplete ? (
              <div className="space-y-4">
                <p className="text-xs sm:text-sm font-semibold text-neutral-900 dark:text-white leading-relaxed">
                  {SAMPLE_QUIZ_QUESTIONS[currentQuestionIndex].question}
                </p>

                <div className="space-y-2">
                  {SAMPLE_QUIZ_QUESTIONS[currentQuestionIndex].options.map((opt, idx) => {
                    const isSelected = selectedAnswer === idx;
                    const isCorrect =
                      idx === SAMPLE_QUIZ_QUESTIONS[currentQuestionIndex].correctAnswerIndex;

                    let btnStyle =
                      'border-neutral-200 dark:border-neutral-800 hover:border-neutral-400 text-neutral-800 dark:text-neutral-200';

                    if (isSelected && !isAnswerSubmitted) {
                      btnStyle =
                        'border-neutral-900 dark:border-white bg-neutral-100 dark:bg-neutral-800 font-semibold';
                    } else if (isAnswerSubmitted) {
                      if (isCorrect) {
                        btnStyle =
                          'border-neutral-900 dark:border-white bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 font-semibold';
                      } else if (isSelected) {
                        btnStyle = 'border-neutral-400 text-neutral-400 line-through';
                      }
                    }

                    return (
                      <button
                        key={idx}
                        disabled={isAnswerSubmitted}
                        onClick={() => setSelectedAnswer(idx)}
                        className={`w-full min-h-[44px] p-3 text-left text-xs rounded-lg border transition-colors flex items-center justify-between ${btnStyle}`}
                      >
                        <span>{opt}</span>
                        {isAnswerSubmitted && isCorrect && (
                          <CheckCircle2 className="w-4 h-4 shrink-0" />
                        )}
                        {isAnswerSubmitted && isSelected && !isCorrect && (
                          <XCircle className="w-4 h-4 shrink-0 text-neutral-400" />
                        )}
                      </button>
                    );
                  })}
                </div>

                {isAnswerSubmitted && (
                  <div className="p-3 bg-neutral-50 dark:bg-neutral-800/50 rounded-lg text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed border border-neutral-200 dark:border-neutral-700">
                    <span className="font-bold text-neutral-900 dark:text-white block mb-0.5">
                      Explanation:
                    </span>
                    {SAMPLE_QUIZ_QUESTIONS[currentQuestionIndex].explanation}
                  </div>
                )}

                <div className="flex justify-end gap-2 pt-2">
                  {!isAnswerSubmitted ? (
                    <button
                      onClick={handleAnswerSubmit}
                      disabled={selectedAnswer === null}
                      className="min-h-[44px] px-5 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 rounded-lg text-xs font-semibold disabled:opacity-40"
                    >
                      Check Answer
                    </button>
                  ) : (
                    <button
                      onClick={handleNextQuestion}
                      className="min-h-[44px] px-5 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 rounded-lg text-xs font-semibold"
                    >
                      {currentQuestionIndex < SAMPLE_QUIZ_QUESTIONS.length - 1
                        ? 'Next Question'
                        : 'View Results'}
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="text-center py-6 space-y-4">
                <div className="text-3xl font-extrabold text-neutral-900 dark:text-white font-mono tabular-nums">
                  {quizScore} / {SAMPLE_QUIZ_QUESTIONS.length}
                </div>
                <p className="text-xs text-neutral-600 dark:text-neutral-400">
                  {quizScore === SAMPLE_QUIZ_QUESTIONS.length
                    ? 'Outstanding! You have mastered these graph theory and complexity fundamentals.'
                    : 'Good practice! Review the slide notes in Vault to solidify edge invariants.'}
                </p>
                <div className="flex justify-center gap-2 pt-2">
                  <button
                    onClick={startQuiz}
                    className="min-h-[44px] px-4 py-2 border border-neutral-300 dark:border-neutral-700 rounded-lg text-xs font-semibold"
                  >
                    Retake Quiz
                  </button>
                  <button
                    onClick={() => setActiveQuizOpen(false)}
                    className="min-h-[44px] px-5 py-2 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 rounded-lg text-xs font-semibold"
                  >
                    Done
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Interactive Flashcard Deck Runner Modal */}
      {activeFlashcardsOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-100 dark:border-neutral-800 pb-3">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-neutral-500">
                  Card {flashcardIndex + 1} of {SAMPLE_FLASHCARDS.length}
                </span>
                <h3 className="text-sm font-bold text-neutral-900 dark:text-white">
                  {SAMPLE_FLASHCARDS[flashcardIndex].topic}
                </h3>
              </div>
              <button
                onClick={() => setActiveFlashcardsOpen(false)}
                className="text-xs text-neutral-400 hover:text-neutral-900 dark:hover:text-white"
              >
                ✕
              </button>
            </div>

            {/* Flashcard Body (Tap to flip) */}
            <div
              onClick={() => setIsFlipped(!isFlipped)}
              className="min-h-[190px] p-6 bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-200 dark:border-neutral-700 rounded-xl flex flex-col items-center justify-center text-center cursor-pointer select-none transition-all hover:border-neutral-400"
            >
              <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-400 mb-2">
                {isFlipped ? 'Answer' : 'Question (Tap to flip)'}
              </span>
              <p className="text-sm font-semibold text-neutral-900 dark:text-white leading-relaxed">
                {isFlipped
                  ? SAMPLE_FLASHCARDS[flashcardIndex].answer
                  : SAMPLE_FLASHCARDS[flashcardIndex].prompt}
              </p>
            </div>

            {/* Deck Navigation Controls */}
            <div className="flex items-center justify-between pt-2">
              <button
                disabled={flashcardIndex === 0}
                onClick={() => {
                  setFlashcardIndex((prev) => prev - 1);
                  setIsFlipped(false);
                }}
                className="min-h-[44px] px-3 text-xs flex items-center gap-1 border border-neutral-200 dark:border-neutral-800 rounded-lg disabled:opacity-30"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Prev</span>
              </button>

              <button
                onClick={() => setIsFlipped(!isFlipped)}
                className="min-h-[44px] px-3 text-xs flex items-center gap-1 text-neutral-500 hover:text-neutral-900 dark:hover:text-white"
              >
                <RotateCw className="w-3.5 h-3.5" />
                <span>Flip Card</span>
              </button>

              <button
                disabled={flashcardIndex === SAMPLE_FLASHCARDS.length - 1}
                onClick={() => {
                  setFlashcardIndex((prev) => prev + 1);
                  setIsFlipped(false);
                }}
                className="min-h-[44px] px-3 text-xs flex items-center gap-1 border border-neutral-200 dark:border-neutral-800 rounded-lg disabled:opacity-30"
              >
                <span>Next</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Revision Note Modal */}
      {activeNoteTopic && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl max-w-md w-full p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-neutral-900 dark:text-white">
                Revision Note Summary
              </h3>
              <button
                onClick={() => setActiveNoteTopic(null)}
                className="text-xs text-neutral-400 hover:text-neutral-900 dark:hover:text-white"
              >
                ✕
              </button>
            </div>
            <p className="text-xs text-neutral-700 dark:text-neutral-300 leading-relaxed">
              {activeNoteTopic}
            </p>
            <div className="flex justify-end pt-2">
              <button
                onClick={() => setActiveNoteTopic(null)}
                className="min-h-[40px] px-4 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 rounded-lg text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
